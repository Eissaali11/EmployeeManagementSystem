# نُظم - نظام إدارة الموظفين
# CloudPanel Deployment Package

## محتويات الحزمة:
1. cloudpanel_requirements.txt - متطلبات Python
2. cloudpanel_deploy.sh - سكريبت النشر الآلي
3. cloudpanel_env_template.txt - قالب متغيرات البيئة
4. cloudpanel_setup_guide.md - دليل النشر المفصل

## خطوات سريعة للنشر:
1. رفع الملفات لمجلد الموقع في CloudPanel
2. تشغيل: chmod +x cloudpanel_deploy.sh && ./cloudpanel_deploy.sh
3. تكوين متغيرات البيئة في ملف .env
4. إنشاء قاعدة البيانات PostgreSQL
5. تشغيل الخدمة

للمزيد من التفاصيل، راجع ملف cloudpanel_setup_guide.md
