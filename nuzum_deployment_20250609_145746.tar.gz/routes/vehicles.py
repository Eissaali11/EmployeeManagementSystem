from datetime import datetime, timedelta
from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, current_app, send_file
from flask_login import login_required, current_user
from flask_wtf import FlaskForm
from werkzeug.utils import secure_filename
from sqlalchemy import extract, func, or_
from forms.vehicle_forms import VehicleAccidentForm, VehicleDocumentsForm
import os
import uuid
import io
import urllib.parse
import pandas as pd
from fpdf import FPDF

from app import db
from models import (
    Vehicle, VehicleRental, VehicleWorkshop, VehicleWorkshopImage, 
    VehicleProject, VehicleHandover, VehicleHandoverImage, SystemAudit,
    VehiclePeriodicInspection, VehicleSafetyCheck, VehicleAccident, Employee,
    Department
)
from utils.audit_logger import log_activity
from utils.vehicles_export import export_vehicle_pdf, export_workshop_records_pdf, export_vehicle_excel, export_workshop_records_excel
from utils.simple_pdf_generator import create_vehicle_handover_pdf as generate_complete_vehicle_report
# from utils.vehicle_excel_report import generate_complete_vehicle_excel_report
# from utils.workshop_report import generate_workshop_report_pdf
# from utils.html_to_pdf import generate_pdf_from_template
# from utils.fpdf_arabic_report import generate_workshop_report_pdf_fpdf
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
import arabic_reshaper
from bidi.algorithm import get_display

vehicles_bp = Blueprint('vehicles', __name__, url_prefix='/vehicles')

def update_vehicle_driver(vehicle_id):
    """تحديث اسم السائق في جدول السيارات بناءً على آخر سجل تسليم من نوع delivery"""
    try:
        # الحصول على جميع سجلات التسليم (delivery) للسيارة مرتبة حسب التاريخ
        delivery_records = VehicleHandover.query.filter_by(
            vehicle_id=vehicle_id, 
            handover_type='delivery'
        ).order_by(VehicleHandover.handover_date.desc()).all()
        
        if delivery_records:
            # أخذ أحدث سجل تسليم (delivery)
            latest_delivery = delivery_records[0]
            
            # تحديد اسم السائق (إما من جدول الموظفين أو من اسم الشخص المدخل يدوياً)
            driver_name = None
            if latest_delivery.employee_id:
                employee = Employee.query.get(latest_delivery.employee_id)
                if employee:
                    driver_name = employee.name
            
            # إذا لم يكن هناك موظف معين، استخدم اسم الشخص المدخل يدوياً
            if not driver_name and latest_delivery.person_name:
                driver_name = latest_delivery.person_name
            
            # تحديث اسم السائق في جدول السيارات
            vehicle = Vehicle.query.get(vehicle_id)
            if vehicle:
                vehicle.driver_name = driver_name
                db.session.commit()
        else:
            # إذا لم يكن هناك سجلات تسليم، امسح اسم السائق
            vehicle = Vehicle.query.get(vehicle_id)
            if vehicle:
                vehicle.driver_name = None
                db.session.commit()
                
    except Exception as e:
        print(f"خطأ في تحديث اسم السائق: {e}")
        # لا نريد أن يؤثر هذا الخطأ على العملية الأساسية
        pass

def update_all_vehicle_drivers():
    """تحديث أسماء جميع السائقين في جدول السيارات"""
    vehicles = Vehicle.query.all()
    updated_count = 0
    
    for vehicle in vehicles:
        update_vehicle_driver(vehicle.id)
        updated_count += 1
    
    return updated_count

def get_vehicle_current_employee_id(vehicle_id):
    """الحصول على معرف الموظف الحالي للسيارة"""
    latest_delivery = VehicleHandover.query.filter_by(
        vehicle_id=vehicle_id, 
        handover_type='delivery'
    ).order_by(VehicleHandover.handover_date.desc()).first()
    
    if latest_delivery and latest_delivery.employee_id:
        return latest_delivery.employee_id
    return None

# قائمة بأهم حالات السيارة للاختيار منها في النماذج
VEHICLE_STATUS_CHOICES = [
    'available',  # متاحة
    'rented',  # مؤجرة
    'in_project',  # في المشروع
    'in_workshop',  # في الورشة
    'accident'  # حادث
]

# قائمة بأسباب دخول الورشة
WORKSHOP_REASON_CHOICES = [
    'maintenance',  # صيانة دورية
    'breakdown',  # عطل
    'accident'  # حادث
]

# قائمة بحالات الإصلاح في الورشة
REPAIR_STATUS_CHOICES = [
    'in_progress',  # قيد التنفيذ
    'completed',  # تم الإصلاح
    'pending_approval'  # بانتظار الموافقة
]

# قائمة بأنواع عمليات التسليم والاستلام
HANDOVER_TYPE_CHOICES = [
    'delivery',  # تسليم
    'return'  # استلام
]

# قائمة بأنواع الفحص الدوري
INSPECTION_TYPE_CHOICES = [
    'technical',  # فحص فني
    'periodic',   # فحص دوري
    'safety'      # فحص أمان
]

# قائمة بحالات الفحص الدوري
INSPECTION_STATUS_CHOICES = [
    'valid',          # ساري
    'expired',        # منتهي
    'expiring_soon'   # على وشك الانتهاء
]

# قائمة بأنواع فحص السلامة
SAFETY_CHECK_TYPE_CHOICES = [
    'daily',    # يومي
    'weekly',   # أسبوعي
    'monthly'   # شهري
]

# قائمة بحالات فحص السلامة
SAFETY_CHECK_STATUS_CHOICES = [
    'completed',      # مكتمل
    'in_progress',    # قيد التنفيذ
    'needs_review'    # بحاجة للمراجعة
]

# الوظائف المساعدة
def save_file(file, folder='vehicles'):
    """حفظ الملف (صورة أو PDF) في المجلد المحدد وإرجاع المسار ونوع الملف"""
    if not file:
        return None, None
    
    # إنشاء اسم فريد للملف
    filename = secure_filename(file.filename)
    unique_filename = f"{uuid.uuid4()}_{filename}"
    
    # التأكد من وجود المجلد
    upload_folder = os.path.join(current_app.static_folder, 'uploads', folder)
    os.makedirs(upload_folder, exist_ok=True)
    
    # حفظ الملف
    file_path = os.path.join(upload_folder, unique_filename)
    file.save(file_path)
    
    # تحديد نوع الملف (صورة أو PDF)
    file_type = 'pdf' if filename.lower().endswith('.pdf') else 'image'
    
    # إرجاع المسار النسبي للملف ونوعه
    return f"uploads/{folder}/{unique_filename}", file_type

# للحفاظ على التوافق مع الكود القديم
def save_image(file, folder='vehicles'):
    """وظيفة محفوظة للتوافق مع الكود القديم"""
    file_path, _ = save_file(file, folder)
    return file_path

def format_date_arabic(date_obj):
    """تنسيق التاريخ باللغة العربية"""
    months = {
        1: 'يناير', 2: 'فبراير', 3: 'مارس', 4: 'أبريل', 
        5: 'مايو', 6: 'يونيو', 7: 'يوليو', 8: 'أغسطس',
        9: 'سبتمبر', 10: 'أكتوبر', 11: 'نوفمبر', 12: 'ديسمبر'
    }
    return f"{date_obj.day} {months[date_obj.month]} {date_obj.year}"

def log_audit(action, entity_type, entity_id, details=None):
    """تسجيل الإجراء في سجل النظام - تم الانتقال للنظام الجديد"""
    log_activity(action, entity_type, entity_id, details)

def calculate_rental_adjustment(vehicle_id, year, month):
    """حساب الخصم على إيجار السيارة بناءً على أيام وجودها في الورشة"""
    # الحصول على الإيجار النشط للسيارة
    rental = VehicleRental.query.filter_by(vehicle_id=vehicle_id, is_active=True).first()
    if not rental:
        return 0
    
    # الحصول على سجلات الورشة للسيارة في الشهر والسنة المحددين
    workshop_records = VehicleWorkshop.query.filter_by(vehicle_id=vehicle_id).filter(
        extract('year', VehicleWorkshop.entry_date) == year,
        extract('month', VehicleWorkshop.entry_date) == month
    ).all()
    
    # حساب عدد الأيام التي قضتها السيارة في الورشة
    total_days_in_workshop = 0
    for record in workshop_records:
        if record.exit_date:
            # إذا كان هناك تاريخ خروج، نحسب الفرق بين تاريخ الدخول والخروج
            delta = (record.exit_date - record.entry_date).days
            total_days_in_workshop += delta
        else:
            # إذا لم يكن هناك تاريخ خروج، نحسب الفرق حتى نهاية الشهر
            last_day_of_month = 30  # تقريبي، يمكن تحسينه
            entry_day = record.entry_date.day
            days_remaining = last_day_of_month - entry_day
            total_days_in_workshop += days_remaining
    
    # حساب الخصم اليومي (الإيجار الشهري / 30)
    daily_rent = rental.monthly_cost / 30
    adjustment = daily_rent * total_days_in_workshop
    
    return adjustment

# المسارات الأساسية
@vehicles_bp.route('/expired-documents')
@login_required
def expired_documents():
    """عرض قائمة المستندات المنتهية للمركبات بشكل تفصيلي"""
    # التاريخ الحالي
    today = datetime.now().date()
    
    # السيارات ذات استمارة منتهية
    expired_registration = Vehicle.query.filter(
        Vehicle.registration_expiry_date.isnot(None),
        Vehicle.registration_expiry_date < today
    ).order_by(Vehicle.registration_expiry_date).all()
    
    # السيارات ذات فحص دوري منتهي
    expired_inspection = Vehicle.query.filter(
        Vehicle.inspection_expiry_date.isnot(None),
        Vehicle.inspection_expiry_date < today
    ).order_by(Vehicle.inspection_expiry_date).all()
    
    # السيارات ذات تفويض منتهي
    expired_authorization = Vehicle.query.filter(
        Vehicle.authorization_expiry_date.isnot(None),
        Vehicle.authorization_expiry_date < today
    ).order_by(Vehicle.authorization_expiry_date).all()
    
    # جميع السيارات التي تحتوي على وثيقة منتهية واحدة على الأقل
    expired_all = Vehicle.query.filter(
        or_(
            Vehicle.registration_expiry_date.isnot(None) & (Vehicle.registration_expiry_date < today),
            Vehicle.inspection_expiry_date.isnot(None) & (Vehicle.inspection_expiry_date < today),
            Vehicle.authorization_expiry_date.isnot(None) & (Vehicle.authorization_expiry_date < today)
        )
    ).order_by(Vehicle.plate_number).all()
    
    return render_template(
        'vehicles/expired_documents.html',
        expired_registration=expired_registration,
        expired_inspection=expired_inspection,
        expired_authorization=expired_authorization,
        expired_all=expired_all,
        today=today
    )
@vehicles_bp.route('/expired-documents/export/excel')
@login_required
def export_expired_documents_excel():
    """تصدير بيانات الوثائق المنتهية للمركبات إلى ملف Excel منسق"""
    # التاريخ الحالي
    today = datetime.now().date()
    
    # السيارات ذات استمارة منتهية
    expired_registration = Vehicle.query.filter(
        Vehicle.registration_expiry_date.isnot(None),
        Vehicle.registration_expiry_date < today
    ).order_by(Vehicle.registration_expiry_date).all()
    
    # السيارات ذات فحص دوري منتهي
    expired_inspection = Vehicle.query.filter(
        Vehicle.inspection_expiry_date.isnot(None),
        Vehicle.inspection_expiry_date < today
    ).order_by(Vehicle.inspection_expiry_date).all()
    
    # السيارات ذات تفويض منتهي
    expired_authorization = Vehicle.query.filter(
        Vehicle.authorization_expiry_date.isnot(None),
        Vehicle.authorization_expiry_date < today
    ).order_by(Vehicle.authorization_expiry_date).all()
    
    # إنشاء قوائم البيانات
    registration_data = []
    for vehicle in expired_registration:
        days_expired = (today - vehicle.registration_expiry_date).days
        registration_data.append({
            'رقم اللوحة': vehicle.plate_number,
            'الشركة المصنعة': vehicle.make,
            'الموديل': vehicle.model,
            'السنة': vehicle.year,
            'تاريخ انتهاء الاستمارة': vehicle.registration_expiry_date.strftime('%Y-%m-%d'),
            'عدد أيام الانتهاء': days_expired,
            'نوع الوثيقة': 'استمارة السيارة'
        })
    
    inspection_data = []
    for vehicle in expired_inspection:
        days_expired = (today - vehicle.inspection_expiry_date).days
        inspection_data.append({
            'رقم اللوحة': vehicle.plate_number,
            'الشركة المصنعة': vehicle.make,
            'الموديل': vehicle.model,
            'السنة': vehicle.year,
            'تاريخ انتهاء الفحص': vehicle.inspection_expiry_date.strftime('%Y-%m-%d'),
            'عدد أيام الانتهاء': days_expired,
            'نوع الوثيقة': 'الفحص الدوري'
        })
    
    authorization_data = []
    for vehicle in expired_authorization:
        days_expired = (today - vehicle.authorization_expiry_date).days
        authorization_data.append({
            'رقم اللوحة': vehicle.plate_number,
            'الشركة المصنعة': vehicle.make,
            'الموديل': vehicle.model,
            'السنة': vehicle.year,
            'تاريخ انتهاء التفويض': vehicle.authorization_expiry_date.strftime('%Y-%m-%d'),
            'عدد أيام الانتهاء': days_expired,
            'نوع الوثيقة': 'التفويض'
        })
    
    # إنشاء مخرج Excel في الذاكرة
    output = io.BytesIO()
    
    # استخدام ExcelWriter مع خيارات التنسيق
    with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
        # إنشاء أوراق العمل لكل نوع من الوثائق
        if registration_data:
            reg_df = pd.DataFrame(registration_data)
            reg_df.to_excel(writer, sheet_name='استمارات منتهية', index=False)
            
            # تنسيق ورقة الاستمارات
            workbook = writer.book
            worksheet = writer.sheets['استمارات منتهية']
            
            # تنسيق العناوين
            header_format = workbook.add_format({
                'bold': True,
                'text_wrap': True,
                'valign': 'top',
                'fg_color': '#FFD7D7',  # خلفية حمراء فاتحة
                'border': 1,
                'align': 'center'
            })
            
            # تنسيق عناوين الأعمدة
            for col_num, value in enumerate(reg_df.columns.values):
                worksheet.write(0, col_num, value, header_format)
                # ضبط عرض العمود
                worksheet.set_column(col_num, col_num, 18)
            
            # تنسيق صفوف البيانات
            data_format = workbook.add_format({
                'border': 1,
                'align': 'center'
            })
            
            # تطبيق التنسيق على كل الخلايا
            for row in range(1, len(reg_df) + 1):
                for col in range(len(reg_df.columns)):
                    worksheet.write(row, col, reg_df.iloc[row-1, col], data_format)
            
            # تنسيق عمود أيام الانتهاء
            days_col = reg_df.columns.get_loc('عدد أيام الانتهاء')
            days_format = workbook.add_format({
                'border': 1,
                'align': 'center',
                'fg_color': '#FFCCCC'  # خلفية حمراء فاتحة للإبراز
            })
            
            for row in range(1, len(reg_df) + 1):
                worksheet.write(row, days_col, reg_df.iloc[row-1, days_col], days_format)
        
        # تنسيق ورقة الفحص الدوري
        if inspection_data:
            insp_df = pd.DataFrame(inspection_data)
            insp_df.to_excel(writer, sheet_name='فحص دوري منتهي', index=False)
            
            # تنسيق ورقة الفحص الدوري
            workbook = writer.book
            worksheet = writer.sheets['فحص دوري منتهي']
            
            # تنسيق العناوين
            header_format = workbook.add_format({
                'bold': True,
                'text_wrap': True,
                'valign': 'top',
                'fg_color': '#D7E4BC',  # خلفية خضراء فاتحة
                'border': 1,
                'align': 'center'
            })
            
            # تنسيق عناوين الأعمدة
            for col_num, value in enumerate(insp_df.columns.values):
                worksheet.write(0, col_num, value, header_format)
                # ضبط عرض العمود
                worksheet.set_column(col_num, col_num, 18)
            
            # تنسيق صفوف البيانات
            data_format = workbook.add_format({
                'border': 1,
                'align': 'center'
            })
            
            # تطبيق التنسيق على كل الخلايا
            for row in range(1, len(insp_df) + 1):
                for col in range(len(insp_df.columns)):
                    worksheet.write(row, col, insp_df.iloc[row-1, col], data_format)
            
            # تنسيق عمود أيام الانتهاء
            days_col = insp_df.columns.get_loc('عدد أيام الانتهاء')
            days_format = workbook.add_format({
                'border': 1,
                'align': 'center',
                'fg_color': '#E2EFDA'  # خلفية خضراء فاتحة للإبراز
            })
            
            for row in range(1, len(insp_df) + 1):
                worksheet.write(row, days_col, insp_df.iloc[row-1, days_col], days_format)
        
        # تنسيق ورقة التفويض
        if authorization_data:
            auth_df = pd.DataFrame(authorization_data)
            auth_df.to_excel(writer, sheet_name='تفويض منتهي', index=False)
            
            # تنسيق ورقة التفويض
            workbook = writer.book
            worksheet = writer.sheets['تفويض منتهي']
            
            # تنسيق العناوين
            header_format = workbook.add_format({
                'bold': True,
                'text_wrap': True,
                'valign': 'top',
                'fg_color': '#B4C6E7',  # خلفية زرقاء فاتحة
                'border': 1,
                'align': 'center'
            })
            
            # تنسيق عناوين الأعمدة
            for col_num, value in enumerate(auth_df.columns.values):
                worksheet.write(0, col_num, value, header_format)
                # ضبط عرض العمود
                worksheet.set_column(col_num, col_num, 18)
            
            # تنسيق صفوف البيانات
            data_format = workbook.add_format({
                'border': 1,
                'align': 'center'
            })
            
            # تطبيق التنسيق على كل الخلايا
            for row in range(1, len(auth_df) + 1):
                for col in range(len(auth_df.columns)):
                    worksheet.write(row, col, auth_df.iloc[row-1, col], data_format)
            
            # تنسيق عمود أيام الانتهاء
            days_col = auth_df.columns.get_loc('عدد أيام الانتهاء')
            days_format = workbook.add_format({
                'border': 1,
                'align': 'center',
                'fg_color': '#DDEBF7'  # خلفية زرقاء فاتحة للإبراز
            })
            
            for row in range(1, len(auth_df) + 1):
                worksheet.write(row, days_col, auth_df.iloc[row-1, days_col], days_format)
        
        # إنشاء ورقة ملخص
        summary_data = {
            'نوع الوثيقة': ['الاستمارة', 'الفحص الدوري', 'التفويض', 'الإجمالي'],
            'عدد الوثائق المنتهية': [
                len(expired_registration),
                len(expired_inspection),
                len(expired_authorization),
                len(expired_registration) + len(expired_inspection) + len(expired_authorization)
            ]
        }
        
        summary_df = pd.DataFrame(summary_data)
        summary_df.to_excel(writer, sheet_name='ملخص', index=False)
        
        # تنسيق ورقة الملخص
        workbook = writer.book
        worksheet = writer.sheets['ملخص']
        
        # تنسيق العناوين
        header_format = workbook.add_format({
            'bold': True,
            'text_wrap': True,
            'valign': 'top',
            'fg_color': '#BDD7EE',  # خلفية زرقاء فاتحة
            'border': 1,
            'align': 'center',
            'font_size': 12
        })
        
        # تنسيق عناوين الأعمدة
        for col_num, value in enumerate(summary_df.columns.values):
            worksheet.write(0, col_num, value, header_format)
            # ضبط عرض العمود
            worksheet.set_column(col_num, col_num, 25)
        
        # تنسيقات مختلفة للأنواع المختلفة
        reg_format = workbook.add_format({
            'border': 1, 'align': 'center', 'fg_color': '#FFD7D7'
        })
        
        insp_format = workbook.add_format({
            'border': 1, 'align': 'center', 'fg_color': '#D7E4BC'
        })
        
        auth_format = workbook.add_format({
            'border': 1, 'align': 'center', 'fg_color': '#B4C6E7'
        })
        
        total_format = workbook.add_format({
            'border': 1, 'align': 'center', 'bold': True, 'fg_color': '#FFC000', 'font_size': 12
        })
        
        # تطبيق التنسيقات
        worksheet.write(1, 0, summary_df.iloc[0, 0], reg_format)
        worksheet.write(1, 1, summary_df.iloc[0, 1], reg_format)
        
        worksheet.write(2, 0, summary_df.iloc[1, 0], insp_format)
        worksheet.write(2, 1, summary_df.iloc[1, 1], insp_format)
        
        worksheet.write(3, 0, summary_df.iloc[2, 0], auth_format)
        worksheet.write(3, 1, summary_df.iloc[2, 1], auth_format)
        
        worksheet.write(4, 0, summary_df.iloc[3, 0], total_format)
        worksheet.write(4, 1, summary_df.iloc[3, 1], total_format)
        
        # إضافة مخطط دائري
        chart = workbook.add_chart({'type': 'pie'})
        chart.add_series({
            'name': 'توزيع الوثائق المنتهية',
            'categories': ['ملخص', 1, 0, 3, 0],
            'values': ['ملخص', 1, 1, 3, 1],
            'points': [
                {'fill': {'color': '#FFD7D7'}},  # الاستمارة
                {'fill': {'color': '#D7E4BC'}},  # الفحص الدوري
                {'fill': {'color': '#B4C6E7'}}   # التفويض
            ],
            'data_labels': {'value': True, 'category': True, 'percentage': True}
        })
        
        chart.set_title({'name': 'توزيع الوثائق المنتهية'})
        chart.set_style(10)
        chart.set_size({'width': 500, 'height': 300})
        worksheet.insert_chart('D2', chart)
    
    # التحضير لإرسال الملف
    output.seek(0)
    
    # اسم الملف بالتاريخ الحالي
    today_str = datetime.now().strftime('%Y-%m-%d')
    filename = f"الوثائق_المنتهية_{today_str}.xlsx"
    
    # تسجيل الإجراء
    log_audit('export', 'vehicle_documents', 0, f'تم تصدير تقرير الوثائق المنتهية للمركبات إلى Excel')
    
    return send_file(
        output,
        download_name=filename,
        as_attachment=True,
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )

@vehicles_bp.route('/')
@login_required
def index():
    """عرض قائمة السيارات مع خيارات التصفية"""
    status_filter = request.args.get('status', '')
    make_filter = request.args.get('make', '')
    
    # قاعدة الاستعلام الأساسية
    query = Vehicle.query
    
    # إضافة التصفية حسب الحالة إذا تم تحديدها
    if status_filter:
        query = query.filter(Vehicle.status == status_filter)
    
    # إضافة التصفية حسب الشركة المصنعة إذا تم تحديدها
    if make_filter:
        query = query.filter(Vehicle.make == make_filter)
    
    # الحصول على قائمة بالشركات المصنعة لقائمة التصفية
    makes = db.session.query(Vehicle.make).distinct().all()
    makes = [make[0] for make in makes]
    
    # الحصول على قائمة السيارات
    vehicles = query.order_by(Vehicle.status, Vehicle.plate_number).all()
    
    # إضافة معرف الموظف الحالي لكل سيارة
    for vehicle in vehicles:
        vehicle.current_employee_id = get_vehicle_current_employee_id(vehicle.id)
    
    # تحقق من تواريخ انتهاء الوثائق والتنبيه بالقريبة للانتهاء
    expiring_documents = []
    today = datetime.now().date()
    thirty_days_later = today + timedelta(days=30)
    
    # احصائيات للوثائق المنتهية أو القريبة من الانتهاء
    for vehicle in vehicles:
        if vehicle.authorization_expiry_date and today <= vehicle.authorization_expiry_date <= thirty_days_later:
            expiring_documents.append({
                'vehicle_id': vehicle.id,
                'plate_number': vehicle.plate_number,
                'document_type': 'authorization',
                'document_name': 'تفويض المركبة',
                'expiry_date': vehicle.authorization_expiry_date,
                'days_remaining': (vehicle.authorization_expiry_date - today).days
            })
            
        if vehicle.registration_expiry_date and today <= vehicle.registration_expiry_date <= thirty_days_later:
            expiring_documents.append({
                'vehicle_id': vehicle.id,
                'plate_number': vehicle.plate_number,
                'document_type': 'registration',
                'document_name': 'استمارة السيارة',
                'expiry_date': vehicle.registration_expiry_date,
                'days_remaining': (vehicle.registration_expiry_date - today).days
            })
            
        if vehicle.inspection_expiry_date and today <= vehicle.inspection_expiry_date <= thirty_days_later:
            expiring_documents.append({
                'vehicle_id': vehicle.id,
                'plate_number': vehicle.plate_number,
                'document_type': 'inspection',
                'document_name': 'الفحص الدوري',
                'expiry_date': vehicle.inspection_expiry_date, 
                'days_remaining': (vehicle.inspection_expiry_date - today).days
            })
    
    # ترتيب الوثائق المنتهية حسب عدد الأيام المتبقية (الأقرب للانتهاء أولاً)
    expiring_documents.sort(key=lambda x: x['days_remaining'])
    
    # إحصائيات سريعة
    stats = {
        'total': Vehicle.query.count(),
        'available': Vehicle.query.filter_by(status='available').count(),
        'rented': Vehicle.query.filter_by(status='rented').count(),
        'in_project': Vehicle.query.filter_by(status='in_project').count(),
        'in_workshop': Vehicle.query.filter_by(status='in_workshop').count(),
        'accident': Vehicle.query.filter_by(status='accident').count()
    }
    
    return render_template(
        'vehicles/index.html',
        vehicles=vehicles,
        stats=stats,
        status_filter=status_filter,
        make_filter=make_filter,
        makes=makes,
        statuses=VEHICLE_STATUS_CHOICES,
        expiring_documents=expiring_documents
    )

@vehicles_bp.route('/create', methods=['GET', 'POST'])
@login_required
def create():
    """إضافة سيارة جديدة"""
    if request.method == 'POST':
        # استخراج البيانات من النموذج
        plate_number = request.form.get('plate_number')
        make = request.form.get('make')
        model = request.form.get('model')
        year = request.form.get('year')
        color = request.form.get('color')
        status = request.form.get('status')
        notes = request.form.get('notes')
        
        # التحقق من عدم وجود سيارة بنفس رقم اللوحة
        if Vehicle.query.filter_by(plate_number=plate_number).first():
            flash('يوجد سيارة مسجلة بنفس رقم اللوحة!', 'danger')
            return redirect(url_for('vehicles.create'))
        
        # إنشاء سيارة جديدة
        driver_name = request.form.get('driver_name')
        vehicle = Vehicle(
            plate_number=plate_number,
            make=make,
            model=model,
            year=int(year),
            color=color,
            status=status,
            driver_name=driver_name,
            notes=notes
        )
        
        db.session.add(vehicle)
        db.session.commit()
        
        # تسجيل الإجراء
        log_audit('create', 'vehicle', vehicle.id, f'تمت إضافة سيارة جديدة: {vehicle.plate_number}')
        
        flash('تمت إضافة السيارة بنجاح!', 'success')
        return redirect(url_for('vehicles.index'))
    
    return render_template('vehicles/create.html', statuses=VEHICLE_STATUS_CHOICES)

@vehicles_bp.route('/<int:id>')
@login_required
def view(id):
    """عرض تفاصيل سيارة معينة"""
    vehicle = Vehicle.query.get_or_404(id)
    
    # الحصول على سجلات مختلفة للسيارة
    rental = VehicleRental.query.filter_by(vehicle_id=id, is_active=True).first()
    workshop_records = VehicleWorkshop.query.filter_by(vehicle_id=id).order_by(VehicleWorkshop.entry_date.desc()).all()
    project_assignments = VehicleProject.query.filter_by(vehicle_id=id).order_by(VehicleProject.start_date.desc()).all()
    handover_records = VehicleHandover.query.filter_by(vehicle_id=id).order_by(VehicleHandover.handover_date.desc()).all()
    
    # الحصول على سجلات الفحص الدوري وفحص السلامة والحوادث
    periodic_inspections = VehiclePeriodicInspection.query.filter_by(vehicle_id=id).order_by(VehiclePeriodicInspection.inspection_date.desc()).all()
    safety_checks = VehicleSafetyCheck.query.filter_by(vehicle_id=id).order_by(VehicleSafetyCheck.check_date.desc()).all()
    accidents = VehicleAccident.query.filter_by(vehicle_id=id).order_by(VehicleAccident.accident_date.desc()).all()
    
    # تاريخ اليوم للاستخدام في حسابات الفرق بين التواريخ
    today = datetime.now().date()
    
    # استخراج معلومات السائق الحالي والسائقين السابقين
    current_driver = None
    previous_drivers = []
    
    # البحث عن آخر سجل تسليم (من حيث التاريخ) للعثور على السائق الحالي
    delivery_records = [rec for rec in handover_records if rec.handover_type == 'delivery']
    delivery_records.sort(key=lambda x: x.handover_date, reverse=True)  # ترتيب حسب التاريخ (الأحدث أولاً)
    
    # تعيين أحدث سجل تسليم كسائق حالي والباقي كسائقين سابقين
    for i, record in enumerate(delivery_records):
        # الحصول على رقم هاتف الموظف إذا كان متوفراً
        phone_number = None
        if record.employee_rel and record.employee_rel.mobile:
            phone_number = record.employee_rel.mobile
            
        if i == 0:  # أول سجل بعد الترتيب (الأحدث)
            current_driver = {
                'name': record.person_name,
                'date': record.handover_date,
                'formatted_date': format_date_arabic(record.handover_date),
                'handover_id': record.id,
                'mobile': phone_number,
                'employee_id': record.employee_id,
                'handover_type': record.handover_type,
                'handover_type_ar': 'استلام' if record.handover_type == 'delivery' else 'تسليم'
            }
        else:
            previous_drivers.append({
                'name': record.person_name,
                'date': record.handover_date,
                'formatted_date': format_date_arabic(record.handover_date),
                'handover_id': record.id,
                'mobile': phone_number,
                'employee_id': record.employee_id,
                'handover_type': record.handover_type,
                'handover_type_ar': 'استلام' if record.handover_type == 'delivery' else 'تسليم'
            })
    
    # ترتيب السائقين السابقين حسب التاريخ (الأحدث أولاً)
    previous_drivers.sort(key=lambda x: x['date'], reverse=True)
    
    # حساب تكلفة الإصلاحات الإجمالية
    total_maintenance_cost = db.session.query(func.sum(VehicleWorkshop.cost)).filter_by(vehicle_id=id).scalar() or 0
    
    # حساب عدد الأيام في الورشة (للسنة الحالية)
    current_year = datetime.now().year
    days_in_workshop = 0
    for record in workshop_records:
        if record.entry_date.year == current_year:
            if record.exit_date:
                days_in_workshop += (record.exit_date - record.entry_date).days
            else:
                days_in_workshop += (datetime.now().date() - record.entry_date).days
    
    # تنسيق التواريخ
    for record in workshop_records:
        record.formatted_entry_date = format_date_arabic(record.entry_date)
        if record.exit_date:
            record.formatted_exit_date = format_date_arabic(record.exit_date)
    
    for record in project_assignments:
        record.formatted_start_date = format_date_arabic(record.start_date)
        if record.end_date:
            record.formatted_end_date = format_date_arabic(record.end_date)
    
    for record in handover_records:
        record.formatted_handover_date = format_date_arabic(record.handover_date)
        # إضافة معلومات رقم الهاتف للسجل
        record.mobile = None
        record.handover_type_ar = 'استلام' if record.handover_type == 'delivery' else 'تسليم'
        if record.employee_rel and record.employee_rel.mobile:
            record.mobile = record.employee_rel.mobile
    
    for record in periodic_inspections:
        record.formatted_inspection_date = format_date_arabic(record.inspection_date)
        record.formatted_expiry_date = format_date_arabic(record.expiry_date)
    
    for record in safety_checks:
        record.formatted_check_date = format_date_arabic(record.check_date)
    
    if rental:
        rental.formatted_start_date = format_date_arabic(rental.start_date)
        if rental.end_date:
            rental.formatted_end_date = format_date_arabic(rental.end_date)
    
    # ملاحظات تنبيهية عن انتهاء الفحص الدوري
    inspection_warnings = []
    for inspection in periodic_inspections:
        if inspection.is_expired:
            inspection_warnings.append(f"الفحص الدوري منتهي الصلاحية منذ {(datetime.now().date() - inspection.expiry_date).days} يومًا")
            break
        elif inspection.is_expiring_soon:
            days_remaining = (inspection.expiry_date - datetime.now().date()).days
            inspection_warnings.append(f"الفحص الدوري سينتهي خلال {days_remaining} يومًا")
            break
    
    return render_template(
        'vehicles/view.html',
        vehicle=vehicle,
        rental=rental,
        workshop_records=workshop_records,
        project_assignments=project_assignments,
        handover_records=handover_records,
        periodic_inspections=periodic_inspections,
        safety_checks=safety_checks,
        accidents=accidents,
        total_maintenance_cost=total_maintenance_cost,
        days_in_workshop=days_in_workshop,
        inspection_warnings=inspection_warnings,
        current_driver=current_driver,
        previous_drivers=previous_drivers,
        today=today
    )

@vehicles_bp.route('/documents/view/<int:id>', methods=['GET'])
@login_required
def view_documents(id):
    """عرض تفاصيل وثائق المركبة"""
    vehicle = Vehicle.query.get_or_404(id)
    
    # حساب الأيام المتبقية للوثائق
    today = datetime.now().date()
    documents_info = []
    
    if vehicle.authorization_expiry_date:
        days_remaining = (vehicle.authorization_expiry_date - today).days
        status = 'صالح'
        status_class = 'success'
        
        if days_remaining < 0:
            status = 'منتهي'
            status_class = 'danger'
        elif days_remaining <= 30:
            status = 'على وشك الانتهاء'
            status_class = 'warning'
            
        documents_info.append({
            'name': 'تفويض المركبة',
            'expiry_date': vehicle.authorization_expiry_date,
            'formatted_date': format_date_arabic(vehicle.authorization_expiry_date),
            'days_remaining': days_remaining,
            'status': status,
            'status_class': status_class
        })
    
    if vehicle.registration_expiry_date:
        days_remaining = (vehicle.registration_expiry_date - today).days
        status = 'صالح'
        status_class = 'success'
        
        if days_remaining < 0:
            status = 'منتهي'
            status_class = 'danger'
        elif days_remaining <= 30:
            status = 'على وشك الانتهاء'
            status_class = 'warning'
            
        documents_info.append({
            'name': 'استمارة السيارة',
            'expiry_date': vehicle.registration_expiry_date,
            'formatted_date': format_date_arabic(vehicle.registration_expiry_date),
            'days_remaining': days_remaining,
            'status': status,
            'status_class': status_class
        })
    
    if vehicle.inspection_expiry_date:
        days_remaining = (vehicle.inspection_expiry_date - today).days
        status = 'صالح'
        status_class = 'success'
        
        if days_remaining < 0:
            status = 'منتهي'
            status_class = 'danger'
        elif days_remaining <= 30:
            status = 'على وشك الانتهاء'
            status_class = 'warning'
            
        documents_info.append({
            'name': 'الفحص الدوري',
            'expiry_date': vehicle.inspection_expiry_date,
            'formatted_date': format_date_arabic(vehicle.inspection_expiry_date),
            'days_remaining': days_remaining,
            'status': status,
            'status_class': status_class
        })
    
    return render_template('vehicles/view_documents.html', vehicle=vehicle, documents_info=documents_info)

@vehicles_bp.route('/documents/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_documents(id):
    """تعديل تواريخ وثائق المركبة (التفويض، الاستمارة، الفحص الدوري)"""
    vehicle = Vehicle.query.get_or_404(id)
    form = VehicleDocumentsForm()
    
    if request.method == 'GET':
        # ملء النموذج بالبيانات الحالية
        form.authorization_expiry_date.data = vehicle.authorization_expiry_date
        form.registration_expiry_date.data = vehicle.registration_expiry_date
        form.inspection_expiry_date.data = vehicle.inspection_expiry_date
    
    if form.validate_on_submit():
        # تحديث البيانات
        vehicle.authorization_expiry_date = form.authorization_expiry_date.data
        vehicle.registration_expiry_date = form.registration_expiry_date.data
        vehicle.inspection_expiry_date = form.inspection_expiry_date.data
        vehicle.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        # تسجيل الإجراء
        log_audit('update', 'vehicle_documents', vehicle.id, f'تم تحديث تواريخ وثائق المركبة: {vehicle.plate_number}')
        
        flash('تم تحديث تواريخ الوثائق بنجاح!', 'success')
        return redirect(url_for('vehicles.view', id=id))
    
    return render_template('vehicles/edit_documents.html', form=form, vehicle=vehicle)

@vehicles_bp.route('/<int:id>/edit', methods=['GET', 'POST'])
@login_required
def edit(id):
    """تعديل بيانات سيارة"""
    vehicle = Vehicle.query.get_or_404(id)
    
    if request.method == 'POST':
        # استخراج البيانات من النموذج
        plate_number = request.form.get('plate_number')
        make = request.form.get('make')
        model = request.form.get('model')
        year = request.form.get('year')
        color = request.form.get('color')
        status = request.form.get('status')
        notes = request.form.get('notes')
        
        # التحقق من عدم وجود سيارة أخرى بنفس رقم اللوحة
        existing = Vehicle.query.filter_by(plate_number=plate_number).first()
        if existing and existing.id != id:
            flash('يوجد سيارة أخرى مسجلة بنفس رقم اللوحة!', 'danger')
            return redirect(url_for('vehicles.edit', id=id))
        
        # تحديث بيانات السيارة
        driver_name = request.form.get('driver_name')
        vehicle.plate_number = plate_number
        vehicle.make = make
        vehicle.model = model
        vehicle.year = int(year)
        vehicle.color = color
        vehicle.status = status
        vehicle.driver_name = driver_name
        vehicle.notes = notes
        vehicle.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        # تسجيل الإجراء
        log_audit('update', 'vehicle', vehicle.id, f'تم تعديل بيانات السيارة: {vehicle.plate_number}')
        
        flash('تم تعديل بيانات السيارة بنجاح!', 'success')
        return redirect(url_for('vehicles.view', id=id))
    
    return render_template('vehicles/edit.html', vehicle=vehicle, statuses=VEHICLE_STATUS_CHOICES)

@vehicles_bp.route('/<int:id>/confirm-delete')
@login_required
def confirm_delete(id):
    """صفحة تأكيد حذف السيارة"""
    vehicle = Vehicle.query.get_or_404(id)
    return render_template('vehicles/confirm_delete.html', vehicle=vehicle)

@vehicles_bp.route('/<int:id>/delete', methods=['POST'])
@login_required
def delete(id):
    """حذف سيارة"""
    vehicle = Vehicle.query.get_or_404(id)
    
    # التحقق من إدخال تأكيد الحذف
    confirmation = request.form.get('confirmation')
    if confirmation != 'تأكيد':
        flash('يجب كتابة كلمة "تأكيد" للمتابعة مع عملية الحذف!', 'danger')
        return redirect(url_for('vehicles.confirm_delete', id=id))
    
    # تسجيل الإجراء قبل الحذف
    plate_number = vehicle.plate_number
    log_audit('delete', 'vehicle', id, f'تم حذف السيارة: {plate_number}')
    
    db.session.delete(vehicle)
    db.session.commit()
    
    flash('تم حذف السيارة ومعلوماتها بنجاح!', 'success')
    return redirect(url_for('vehicles.index'))

# مسارات إدارة الحوادث المرورية
@vehicles_bp.route('/<int:id>/accident/create', methods=['GET', 'POST'])
@login_required
def create_accident(id):
    """إضافة سجل حادث مروري جديد"""
    vehicle = Vehicle.query.get_or_404(id)
    form = VehicleAccidentForm()
    form.vehicle_id.data = id
    
    if form.validate_on_submit():
        accident = VehicleAccident(
            vehicle_id=id,
            accident_date=form.accident_date.data,
            driver_name=form.driver_name.data,
            accident_status=form.accident_status.data,
            vehicle_condition=form.vehicle_condition.data,
            deduction_amount=form.deduction_amount.data,
            deduction_status=form.deduction_status.data,
            liability_percentage=form.liability_percentage.data,
            accident_file_link=form.accident_file_link.data,
            location=form.location.data,
            police_report=form.police_report.data,
            insurance_claim=form.insurance_claim.data,
            description=form.description.data,
            notes=form.notes.data
        )
        
        db.session.add(accident)
        
        # تحديث حالة السيارة إذا كان الحادث شديد
        if form.vehicle_condition.data and 'شديد' in form.vehicle_condition.data:
            vehicle.status = 'accident'
            vehicle.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        # تسجيل الإجراء
        log_audit('create', 'vehicle_accident', accident.id, 
                 f'تم إضافة سجل حادث مروري للسيارة: {vehicle.plate_number}')
        
        flash('تم إضافة سجل الحادث المروري بنجاح!', 'success')
        return redirect(url_for('vehicles.view', id=id))
    
    return render_template('vehicles/create_accident.html', form=form, vehicle=vehicle)

@vehicles_bp.route('/accident/<int:id>/edit', methods=['GET', 'POST'])
@login_required
def edit_accident(id):
    """تعديل سجل حادث مروري"""
    accident = VehicleAccident.query.get_or_404(id)
    vehicle = Vehicle.query.get_or_404(accident.vehicle_id)
    form = VehicleAccidentForm(obj=accident)
    
    if form.validate_on_submit():
        form.populate_obj(accident)
        accident.updated_at = datetime.utcnow()
        
        # تحديث حالة السيارة إذا كان الحادث شديد
        if form.vehicle_condition.data and 'شديد' in form.vehicle_condition.data:
            vehicle.status = 'accident'
        elif accident.accident_status == 'مغلق':
            # إعادة حالة السيارة إلى متاحة إذا تم إغلاق الحادث
            vehicle.status = 'available'
        
        vehicle.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        # تسجيل الإجراء
        log_audit('update', 'vehicle_accident', accident.id, 
                 f'تم تعديل سجل حادث مروري للسيارة: {vehicle.plate_number}')
        
        flash('تم تعديل سجل الحادث المروري بنجاح!', 'success')
        return redirect(url_for('vehicles.view', id=vehicle.id))
    
    return render_template('vehicles/edit_accident.html', form=form, accident=accident)

@vehicles_bp.route('/accident/<int:id>/confirm-delete')
@login_required
def confirm_delete_accident(id):
    """عرض صفحة تأكيد حذف سجل حادث مروري"""
    accident = VehicleAccident.query.get_or_404(id)
    return render_template('vehicles/delete_accident.html', accident=accident)

@vehicles_bp.route('/accident/<int:id>/delete', methods=['POST'])
@login_required
def delete_accident(id):
    """حذف سجل حادث مروري"""
    accident = VehicleAccident.query.get_or_404(id)
    vehicle_id = accident.vehicle_id
    vehicle = Vehicle.query.get(vehicle_id)
    
    # تسجيل الإجراء قبل الحذف
    log_audit('delete', 'vehicle_accident', id, 
             f'تم حذف سجل حادث مروري للسيارة: {vehicle.plate_number}')
    
    db.session.delete(accident)
    
    # تحقق مما إذا كانت حالة السيارة 'accident' وقم بتحديثها إلى 'available'
    # فقط إذا لم يكن لديها سجلات حوادث أخرى
    if vehicle.status == 'accident':
        other_accidents = VehicleAccident.query.filter_by(vehicle_id=vehicle_id).filter(VehicleAccident.id != id).all()
        if not other_accidents:
            vehicle.status = 'available'
            vehicle.updated_at = datetime.utcnow()
    
    db.session.commit()
    
    flash('تم حذف سجل الحادث المروري بنجاح!', 'success')
    return redirect(url_for('vehicles.view', id=vehicle_id))

# مسارات إدارة الإيجار
@vehicles_bp.route('/<int:id>/rental/create', methods=['GET', 'POST'])
@login_required
def create_rental(id):
    """إضافة معلومات إيجار لسيارة"""
    vehicle = Vehicle.query.get_or_404(id)
    
    # التحقق من عدم وجود إيجار نشط حالياً
    existing_rental = VehicleRental.query.filter_by(vehicle_id=id, is_active=True).first()
    if existing_rental and request.method == 'GET':
        flash('يوجد إيجار نشط بالفعل لهذه السيارة!', 'warning')
        return redirect(url_for('vehicles.view', id=id))
    
    if request.method == 'POST':
        # استخراج البيانات من النموذج
        start_date = datetime.strptime(request.form.get('start_date'), '%Y-%m-%d').date()
        end_date_str = request.form.get('end_date')
        end_date = datetime.strptime(end_date_str, '%Y-%m-%d').date() if end_date_str else None
        monthly_cost = float(request.form.get('monthly_cost'))
        lessor_name = request.form.get('lessor_name')
        lessor_contact = request.form.get('lessor_contact')
        contract_number = request.form.get('contract_number')
        city = request.form.get('city')
        notes = request.form.get('notes')
        
        # إلغاء تنشيط الإيجارات السابقة
        if existing_rental:
            existing_rental.is_active = False
            existing_rental.updated_at = datetime.utcnow()
        
        # إنشاء سجل إيجار جديد
        rental = VehicleRental(
            vehicle_id=id,
            start_date=start_date,
            end_date=end_date,
            monthly_cost=monthly_cost,
            is_active=True,
            lessor_name=lessor_name,
            lessor_contact=lessor_contact,
            contract_number=contract_number,
            city=city,
            notes=notes
        )
        
        db.session.add(rental)
        
        # تحديث حالة السيارة
        vehicle.status = 'rented'
        vehicle.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        # تسجيل الإجراء
        log_audit('create', 'vehicle_rental', rental.id, f'تم إضافة معلومات إيجار للسيارة: {vehicle.plate_number}')
        
        flash('تم إضافة معلومات الإيجار بنجاح!', 'success')
        return redirect(url_for('vehicles.view', id=id))
    
    return render_template('vehicles/rental_create.html', vehicle=vehicle)

@vehicles_bp.route('/rental/<int:id>/edit', methods=['GET', 'POST'])
@login_required
def edit_rental(id):
    """تعديل معلومات إيجار"""
    rental = VehicleRental.query.get_or_404(id)
    vehicle = Vehicle.query.get_or_404(rental.vehicle_id)
    
    if request.method == 'POST':
        # استخراج البيانات من النموذج
        start_date = datetime.strptime(request.form.get('start_date'), '%Y-%m-%d').date()
        end_date_str = request.form.get('end_date')
        end_date = datetime.strptime(end_date_str, '%Y-%m-%d').date() if end_date_str else None
        monthly_cost = float(request.form.get('monthly_cost'))
        is_active = bool(request.form.get('is_active'))
        lessor_name = request.form.get('lessor_name')
        lessor_contact = request.form.get('lessor_contact')
        contract_number = request.form.get('contract_number')
        city = request.form.get('city')
        notes = request.form.get('notes')
        
        # تحديث معلومات الإيجار
        rental.start_date = start_date
        rental.end_date = end_date
        rental.monthly_cost = monthly_cost
        rental.is_active = is_active
        rental.lessor_name = lessor_name
        rental.lessor_contact = lessor_contact
        rental.contract_number = contract_number
        rental.city = city
        rental.notes = notes
        rental.updated_at = datetime.utcnow()
        
        # تحديث حالة السيارة حسب حالة الإيجار
        if is_active:
            vehicle.status = 'rented'
        else:
            vehicle.status = 'available'
        vehicle.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        # تسجيل الإجراء
        log_audit('update', 'vehicle_rental', rental.id, f'تم تعديل معلومات إيجار السيارة: {vehicle.plate_number}')
        
        flash('تم تعديل معلومات الإيجار بنجاح!', 'success')
        return redirect(url_for('vehicles.view', id=vehicle.id))
    
    return render_template('vehicles/rental_edit.html', rental=rental, vehicle=vehicle)

# مسارات إدارة الورشة
@vehicles_bp.route('/<int:id>/workshop/create', methods=['GET', 'POST'])
@login_required
def create_workshop(id):
    """إضافة سجل دخول السيارة للورشة"""
    vehicle = Vehicle.query.get_or_404(id)
    
    if request.method == 'POST':
        # استخراج البيانات من النموذج
        entry_date = datetime.strptime(request.form.get('entry_date'), '%Y-%m-%d').date()
        exit_date_str = request.form.get('exit_date')
        exit_date = datetime.strptime(exit_date_str, '%Y-%m-%d').date() if exit_date_str else None
        reason = request.form.get('reason')
        description = request.form.get('description')
        repair_status = request.form.get('repair_status')
        cost = float(request.form.get('cost') or 0)
        workshop_name = request.form.get('workshop_name')
        technician_name = request.form.get('technician_name')
        delivery_link = request.form.get('delivery_link')
        notes = request.form.get('notes')
        
        # إنشاء سجل ورشة جديد
        workshop_record = VehicleWorkshop(
            vehicle_id=id,
            entry_date=entry_date,
            exit_date=exit_date,
            reason=reason,
            description=description,
            repair_status=repair_status,
            cost=cost,
            workshop_name=workshop_name,
            technician_name=technician_name,
            delivery_link=delivery_link,
            notes=notes
        )
        
        db.session.add(workshop_record)
        
        # تحديث حالة السيارة
        if not exit_date:
            vehicle.status = 'in_workshop'
        vehicle.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        # معالجة الصور المرفقة
        before_images = request.files.getlist('before_images')
        after_images = request.files.getlist('after_images')
        
        for image in before_images:
            if image and image.filename:
                image_path = save_image(image, 'workshop')
                if image_path:
                    image_record = VehicleWorkshopImage(
                        workshop_record_id=workshop_record.id,
                        image_type='before',
                        image_path=image_path
                    )
                    db.session.add(image_record)
        
        for image in after_images:
            if image and image.filename:
                image_path = save_image(image, 'workshop')
                if image_path:
                    image_record = VehicleWorkshopImage(
                        workshop_record_id=workshop_record.id,
                        image_type='after',
                        image_path=image_path
                    )
                    db.session.add(image_record)
        
        db.session.commit()
        
        # تسجيل الإجراء
        log_audit('create', 'vehicle_workshop', workshop_record.id, 
                 f'تم إضافة سجل دخول الورشة للسيارة: {vehicle.plate_number}')
        
        flash('تم إضافة سجل دخول الورشة بنجاح!', 'success')
        return redirect(url_for('vehicles.view', id=id))
    
    return render_template(
        'vehicles/workshop_create.html', 
        vehicle=vehicle, 
        reasons=WORKSHOP_REASON_CHOICES,
        statuses=REPAIR_STATUS_CHOICES
    )

@vehicles_bp.route('/workshop/<int:id>/edit', methods=['GET', 'POST'])
@login_required
def edit_workshop(id):
    """تعديل سجل ورشة"""
    current_app.logger.info(f"تم استدعاء edit_workshop مع معرف: {id}, طريقة: {request.method}")
    
    # الحصول على سجل الورشة والسيارة
    workshop = VehicleWorkshop.query.get_or_404(id)
    vehicle = Vehicle.query.get_or_404(workshop.vehicle_id)
    current_app.logger.info(f"تم العثور على سجل الورشة: {workshop.id} للسيارة: {vehicle.plate_number}")
    
    # الحصول على الصور الحالية
    before_images = VehicleWorkshopImage.query.filter_by(workshop_record_id=id, image_type='before').all()
    after_images = VehicleWorkshopImage.query.filter_by(workshop_record_id=id, image_type='after').all()
    current_app.logger.info(f"تم العثور على {len(before_images)} صور قبل و {len(after_images)} صور بعد")
    
    if request.method == 'POST':
        try:
            # تسجيل معلومات النموذج للتصحيح
            current_app.logger.info(f"تم استقبال طلب POST لتعديل سجل الورشة {id}")
            current_app.logger.info(f"بيانات النموذج: {request.form}")
            current_app.logger.info(f"الملفات: {request.files}")
            
            # الحصول على البيانات من الطلب
            entry_date_str = request.form.get('entry_date')
            exit_date_str = request.form.get('exit_date')
            reason = request.form.get('reason')
            description = request.form.get('description')
            repair_status = request.form.get('repair_status')
            cost_str = request.form.get('cost', '0')
            workshop_name = request.form.get('workshop_name')
            technician_name = request.form.get('technician_name')
            delivery_link = request.form.get('delivery_link')
            reception_link = request.form.get('reception_link')
            notes = request.form.get('notes')
            
            # تحويل التواريخ والتكلفة
            entry_date = datetime.strptime(entry_date_str, '%Y-%m-%d').date() if entry_date_str else None
            exit_date = datetime.strptime(exit_date_str, '%Y-%m-%d').date() if exit_date_str else None
            try:
                cost = float(cost_str.replace(',', '.')) if cost_str and cost_str.strip() else 0.0
            except ValueError:
                cost = 0.0
            
            # تحديث سجل الورشة
            workshop.entry_date = entry_date
            workshop.exit_date = exit_date
            workshop.reason = reason
            workshop.description = description
            workshop.repair_status = repair_status
            workshop.cost = cost
            workshop.workshop_name = workshop_name
            workshop.technician_name = technician_name
            workshop.delivery_link = delivery_link
            workshop.reception_link = reception_link
            workshop.notes = notes
            workshop.updated_at = datetime.utcnow()
            
            # تحديث حالة السيارة إذا خرجت من الورشة
            if exit_date and repair_status == 'completed':
                other_active_records = VehicleWorkshop.query.filter(
                    VehicleWorkshop.vehicle_id == vehicle.id,
                    VehicleWorkshop.id != id,
                    VehicleWorkshop.exit_date.is_(None)
                ).count()
                
                if other_active_records == 0:
                    # لا توجد سجلات ورشة نشطة أخرى
                    active_rental = VehicleRental.query.filter_by(vehicle_id=vehicle.id, is_active=True).first()
                    active_project = VehicleProject.query.filter_by(vehicle_id=vehicle.id, is_active=True).first()
                    
                    if active_rental:
                        vehicle.status = 'rented'
                    elif active_project:
                        vehicle.status = 'in_project'
                    else:
                        vehicle.status = 'available'
            
            # تحديث السيارة
            vehicle.updated_at = datetime.utcnow()
            db.session.commit()
            
            # معالجة الصور المرفقة
            before_image_files = request.files.getlist('before_images')
            after_image_files = request.files.getlist('after_images')
            
            for image in before_image_files:
                if image and image.filename:
                    image_path = save_image(image, 'workshop')
                    if image_path:
                        workshop_image = VehicleWorkshopImage(
                            workshop_record_id=id,
                            image_type='before',
                            image_path=image_path
                        )
                        db.session.add(workshop_image)
            
            for image in after_image_files:
                if image and image.filename:
                    image_path = save_image(image, 'workshop')
                    if image_path:
                        workshop_image = VehicleWorkshopImage(
                            workshop_record_id=id,
                            image_type='after',
                            image_path=image_path
                        )
                        db.session.add(workshop_image)
            
            db.session.commit()
            
            # تسجيل الإجراء
            log_audit('update', 'vehicle_workshop', workshop.id, 
                     f'تم تعديل سجل الورشة للسيارة {vehicle.plate_number}')
            
            flash('تم تعديل سجل الورشة بنجاح!', 'success')
            return redirect(url_for('vehicles.view', id=vehicle.id))
            
        except Exception as e:
            current_app.logger.error(f"خطأ في حفظ سجل الورشة: {str(e)}")
            db.session.rollback()
            flash(f'حدث خطأ أثناء حفظ التعديلات: {str(e)}', 'danger')
    
    # عرض النموذج
    return render_template(
        'vehicles/workshop_edit.html', 
        workshop=workshop, 
        vehicle=vehicle,
        before_images=before_images,
        after_images=after_images,
        reasons=WORKSHOP_REASON_CHOICES,
        statuses=REPAIR_STATUS_CHOICES
    )

@vehicles_bp.route('/workshop/image/<int:id>/confirm-delete')
@login_required
def confirm_delete_workshop_image(id):
    """صفحة تأكيد حذف صورة من سجل الورشة"""
    image = VehicleWorkshopImage.query.get_or_404(id)
    workshop = VehicleWorkshop.query.get_or_404(image.workshop_record_id)
    vehicle = Vehicle.query.get_or_404(workshop.vehicle_id)
    
    return render_template(
        'vehicles/confirm_delete_workshop_image.html',
        image=image,
        workshop=workshop,
        vehicle=vehicle
    )

@vehicles_bp.route('/workshop/image/<int:id>/delete', methods=['POST'])
@login_required
def delete_workshop_image(id):
    """حذف صورة من سجل الورشة"""
    image = VehicleWorkshopImage.query.get_or_404(id)
    workshop_id = image.workshop_record_id
    workshop = VehicleWorkshop.query.get_or_404(workshop_id)
    
    # التحقق من إدخال تأكيد الحذف
    confirmation = request.form.get('confirmation')
    if confirmation != 'تأكيد':
        flash('يجب كتابة كلمة "تأكيد" للمتابعة مع عملية الحذف!', 'danger')
        return redirect(url_for('vehicles.confirm_delete_workshop_image', id=id))
    
    # حذف الملف الفعلي إذا كان موجوداً
    file_path = os.path.join(current_app.static_folder, image.image_path)
    if os.path.exists(file_path):
        os.remove(file_path)
    
    db.session.delete(image)
    db.session.commit()
    
    # تسجيل الإجراء
    log_audit('delete', 'vehicle_workshop_image', id, 
             f'تم حذف صورة من سجل الورشة للسيارة: {workshop.vehicle.plate_number}')
    
    flash('تم حذف الصورة بنجاح!', 'success')
    return redirect(url_for('vehicles.edit_workshop', id=workshop_id))

# مسارات إدارة المشاريع
@vehicles_bp.route('/<int:id>/project/create', methods=['GET', 'POST'])
@login_required
def create_project(id):
    """تخصيص السيارة لمشروع"""
    vehicle = Vehicle.query.get_or_404(id)
    
    # التحقق من عدم وجود تخصيص نشط حالياً
    existing_assignment = VehicleProject.query.filter_by(vehicle_id=id, is_active=True).first()
    if existing_assignment and request.method == 'GET':
        flash('هذه السيارة مخصصة بالفعل لمشروع نشط!', 'warning')
        return redirect(url_for('vehicles.view', id=id))
    
    if request.method == 'POST':
        # استخراج البيانات من النموذج
        project_name = request.form.get('project_name')
        location = request.form.get('location')
        manager_name = request.form.get('manager_name')
        start_date = datetime.strptime(request.form.get('start_date'), '%Y-%m-%d').date()
        end_date_str = request.form.get('end_date')
        end_date = datetime.strptime(end_date_str, '%Y-%m-%d').date() if end_date_str else None
        notes = request.form.get('notes')
        
        # إلغاء تنشيط التخصيصات السابقة
        if existing_assignment:
            existing_assignment.is_active = False
            existing_assignment.updated_at = datetime.utcnow()
        
        # إنشاء تخصيص جديد
        project = VehicleProject(
            vehicle_id=id,
            project_name=project_name,
            location=location,
            manager_name=manager_name,
            start_date=start_date,
            end_date=end_date,
            is_active=True,
            notes=notes
        )
        
        db.session.add(project)
        
        # تحديث حالة السيارة
        vehicle.status = 'in_project'
        vehicle.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        # تسجيل الإجراء
        log_audit('create', 'vehicle_project', project.id, 
                 f'تم تخصيص السيارة {vehicle.plate_number} لمشروع {project_name}')
        
        flash('تم تخصيص السيارة للمشروع بنجاح!', 'success')
        return redirect(url_for('vehicles.view', id=id))
    
    return render_template('vehicles/project_create.html', vehicle=vehicle)

@vehicles_bp.route('/project/<int:id>/edit', methods=['GET', 'POST'])
@login_required
def edit_project(id):
    """تعديل تخصيص المشروع"""
    project = VehicleProject.query.get_or_404(id)
    vehicle = Vehicle.query.get_or_404(project.vehicle_id)
    
    if request.method == 'POST':
        # استخراج البيانات من النموذج
        project_name = request.form.get('project_name')
        location = request.form.get('location')
        manager_name = request.form.get('manager_name')
        start_date = datetime.strptime(request.form.get('start_date'), '%Y-%m-%d').date()
        end_date_str = request.form.get('end_date')
        end_date = datetime.strptime(end_date_str, '%Y-%m-%d').date() if end_date_str else None
        is_active = bool(request.form.get('is_active'))
        notes = request.form.get('notes')
        
        # تحديث التخصيص
        project.project_name = project_name
        project.location = location
        project.manager_name = manager_name
        project.start_date = start_date
        project.end_date = end_date
        project.is_active = is_active
        project.notes = notes
        project.updated_at = datetime.utcnow()
        
        # تحديث حالة السيارة
        if is_active:
            vehicle.status = 'in_project'
        else:
            # التحقق مما إذا كانت السيارة مؤجرة
            active_rental = VehicleRental.query.filter_by(vehicle_id=vehicle.id, is_active=True).first()
            
            if active_rental:
                vehicle.status = 'rented'
            else:
                vehicle.status = 'available'
        
        vehicle.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        # تسجيل الإجراء
        log_audit('update', 'vehicle_project', project.id, 
                 f'تم تعديل تخصيص السيارة {vehicle.plate_number} للمشروع {project_name}')
        
        flash('تم تعديل تخصيص المشروع بنجاح!', 'success')
        return redirect(url_for('vehicles.view', id=vehicle.id))
    
    return render_template('vehicles/project_edit.html', project=project, vehicle=vehicle)

# مسارات تسليم واستلام السيارات
@vehicles_bp.route('/<int:id>/handover/create', methods=['GET', 'POST'])
@login_required
def create_handover(id):
    """إنشاء نموذج تسليم/استلام للسيارة"""
    vehicle = Vehicle.query.get_or_404(id)
    
    # تحديد نوع النموذج (تسليم أو استلام) من معلمة الاستعلام
    default_type = request.args.get('type', '')
    if default_type == 'delivery':
        default_handover_type = 'delivery'
    elif default_type == 'receive':
        default_handover_type = 'receive'
    else:
        default_handover_type = None
    
    # جلب قائمة الموظفين والأقسام للاختيار منهم
    employees = Employee.query.order_by(Employee.name).all()
    departments = Department.query.order_by(Department.name).all()
    
    if request.method == 'POST':
        # استخراج البيانات من النموذج
        handover_type = request.form.get('handover_type')
        handover_date = datetime.strptime(request.form.get('handover_date'), '%Y-%m-%d').date()
        person_name = request.form.get('person_name')
        employee_id = request.form.get('employee_id')  # معرف الموظف من النموذج
        vehicle_condition = request.form.get('vehicle_condition')
        fuel_level = request.form.get('fuel_level')
        mileage = int(request.form.get('mileage'))
        has_spare_tire = 'has_spare_tire' in request.form
        has_fire_extinguisher = 'has_fire_extinguisher' in request.form
        has_first_aid_kit = 'has_first_aid_kit' in request.form
        has_warning_triangle = 'has_warning_triangle' in request.form
        has_tools = 'has_tools' in request.form
        form_link = request.form.get('form_link')
        notes = request.form.get('notes')
        
        # إنشاء سجل تسليم/استلام جديد
        handover = VehicleHandover(
            vehicle_id=id,
            handover_type=handover_type,
            handover_date=handover_date,
            person_name=person_name,
            employee_id=int(employee_id) if employee_id else None, # تخزين معرف الموظف إذا تم اختياره
            vehicle_condition=vehicle_condition,
            fuel_level=fuel_level,
            mileage=mileage,
            has_spare_tire=has_spare_tire,
            has_fire_extinguisher=has_fire_extinguisher,
            has_first_aid_kit=has_first_aid_kit,
            has_warning_triangle=has_warning_triangle,
            has_tools=has_tools,
            form_link=form_link,
            notes=notes
        )
        
        db.session.add(handover)
        db.session.commit()
        
        # تحديث اسم السائق في جدول السيارات
        update_vehicle_driver(id)
        
        # معالجة الملفات المرفقة (صور و PDF)
        files = request.files.getlist('files')
        
        for file in files:
            if file and file.filename:
                file_path, file_type = save_file(file, 'handover')
                if file_path:
                    file_description = request.form.get(f'description_{file.filename}', '')
                    # للحفاظ على توافق البيانات، نستخدم نفس القيمة لحقلي image_path و file_path
                    file_record = VehicleHandoverImage(
                        handover_record_id=handover.id,
                        image_path=file_path,  # للتوافق مع القيود على قاعدة البيانات
                        image_description=file_description,  # للتوافق مع القيود على قاعدة البيانات
                        file_path=file_path,
                        file_type=file_type,
                        file_description=file_description
                    )
                    db.session.add(file_record)
        
        db.session.commit()
        
        # تسجيل الإجراء
        action_type = 'تسليم' if handover_type == 'delivery' else 'استلام'
        log_audit('create', 'vehicle_handover', handover.id, 
                 f'تم إنشاء نموذج {action_type} للسيارة: {vehicle.plate_number}')
        
        flash(f'تم إنشاء نموذج {action_type} بنجاح!', 'success')
        return redirect(url_for('vehicles.view', id=id))
    
    return render_template(
        'vehicles/handover_create.html', 
        vehicle=vehicle,
        handover_types=HANDOVER_TYPE_CHOICES,
        default_handover_type=default_handover_type,
        employees=employees,
        departments=departments
    )

@vehicles_bp.route('/handover/<int:id>/view')
@login_required
def view_handover(id):
    """عرض تفاصيل نموذج تسليم/استلام"""
    handover = VehicleHandover.query.get_or_404(id)
    vehicle = Vehicle.query.get_or_404(handover.vehicle_id)
    images = VehicleHandoverImage.query.filter_by(handover_record_id=id).all()
    
    # تنسيق التاريخ
    handover.formatted_handover_date = format_date_arabic(handover.handover_date)
    
    handover_type_name = 'تسليم' if handover.handover_type == 'delivery' else 'استلام'
    
    return render_template(
        'vehicles/handover_view.html',
        handover=handover,
        vehicle=vehicle,
        images=images,
        handover_type_name=handover_type_name
    )

@vehicles_bp.route('/handover/<int:id>/edit', methods=['GET', 'POST'])
@login_required
def edit_handover(id):
    """تعديل بيانات نموذج تسليم/استلام"""
    handover = VehicleHandover.query.get_or_404(id)
    vehicle = Vehicle.query.get_or_404(handover.vehicle_id)
    
    # الحصول على صور نموذج التسليم/الاستلام للعرض
    images = VehicleHandoverImage.query.filter_by(handover_record_id=id).all()
    
    # تحويل التاريخ إلى النسق المناسب للنموذج
    handover_date_str = handover.handover_date.strftime('%Y-%m-%d') if handover.handover_date else None
    
    # تحديد اسم نوع النموذج
    handover_type_name = 'تسليم' if handover.handover_type == 'delivery' else 'استلام'
    
    if request.method == 'POST':
        try:
            # استخراج البيانات من النموذج
            handover_date_str = request.form.get('handover_date')
            person_name = request.form.get('person_name')
            mileage_str = request.form.get('mileage')
            fuel_level = request.form.get('fuel_level')
            vehicle_condition = request.form.get('vehicle_condition')
            form_link = request.form.get('form_link')
            notes = request.form.get('notes')
            
            # معالجة مربعات الاختيار
            has_spare_tire = 'has_spare_tire' in request.form
            has_fire_extinguisher = 'has_fire_extinguisher' in request.form
            has_first_aid_kit = 'has_first_aid_kit' in request.form
            has_warning_triangle = 'has_warning_triangle' in request.form
            has_tools = 'has_tools' in request.form
            
            # تحويل التاريخ والعداد
            handover_date = datetime.strptime(handover_date_str, '%Y-%m-%d').date() if handover_date_str else None
            try:
                mileage = int(mileage_str.replace(',', '')) if mileage_str else 0
            except (ValueError, TypeError) as e:
                flash(f'خطأ في تنسيق قراءة العداد: {str(e)}', 'danger')
                return redirect(url_for('vehicles.edit_handover', id=id))
            
            # تحديث بيانات النموذج
            handover.handover_date = handover_date
            handover.person_name = person_name
            handover.mileage = mileage
            handover.fuel_level = fuel_level
            handover.vehicle_condition = vehicle_condition
            handover.form_link = form_link
            handover.notes = notes
            handover.has_spare_tire = has_spare_tire
            handover.has_fire_extinguisher = has_fire_extinguisher
            handover.has_first_aid_kit = has_first_aid_kit
            handover.has_warning_triangle = has_warning_triangle
            handover.has_tools = has_tools
            handover.updated_at = datetime.utcnow()
            
            db.session.commit()
            
            # تسجيل الإجراء
            log_audit('update', 'vehicle_handover', handover.id, f'تم تعديل نموذج {handover_type_name} للسيارة: {vehicle.plate_number}')
            
            flash(f'تم تعديل بيانات نموذج {handover_type_name} بنجاح!', 'success')
            return redirect(url_for('vehicles.view_handover', id=id))
        
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"Error updating handover form: {str(e)}")
            flash(f'حدث خطأ أثناء تعديل نموذج التسليم/الاستلام: {str(e)}', 'danger')
    
    # جلب قائمة الموظفين للاختيار منهم
    employees = Employee.query.order_by(Employee.name).all()
    departments = Department.query.order_by(Department.name).all()
    
    return render_template(
        'vehicles/edit_handover.html',
        handover=handover,
        vehicle=vehicle,
        images=images,
        handover_date=handover_date_str,
        handover_type_name=handover_type_name,
        employees=employees,
        departments=departments
    )

@vehicles_bp.route('/<int:vehicle_id>/handovers/confirm-delete', methods=['POST'])
@login_required
def confirm_delete_handovers(vehicle_id):
    """صفحة تأكيد حذف سجلات التسليم/الاستلام المحددة"""
    vehicle = Vehicle.query.get_or_404(vehicle_id)
    
    # الحصول على معرفات السجلات المحددة
    record_ids = request.form.getlist('handover_ids[]')
    
    if not record_ids:
        flash('لم يتم تحديد أي سجل للحذف!', 'warning')
        return redirect(url_for('vehicles.view', id=vehicle_id))
    
    # تحويل المعرفات إلى أرقام صحيحة
    record_ids = [int(id) for id in record_ids]
    
    # الحصول على السجلات المحددة
    records = VehicleHandover.query.filter(VehicleHandover.id.in_(record_ids)).all()
    
    # التحقق من أن السجلات تنتمي للسيارة المحددة
    for record in records:
        if record.vehicle_id != vehicle_id:
            flash('خطأ في البيانات المرسلة! بعض السجلات لا تنتمي لهذه السيارة.', 'danger')
            return redirect(url_for('vehicles.view', id=vehicle_id))
    
    # تنسيق التواريخ للعرض
    for record in records:
        record.formatted_handover_date = format_date_arabic(record.handover_date)
    
    return render_template(
        'vehicles/confirm_delete_handovers.html',
        vehicle=vehicle,
        records=records,
        record_ids=record_ids
    )

@vehicles_bp.route('/<int:vehicle_id>/handovers/delete', methods=['POST'])
@login_required
def delete_handovers(vehicle_id):
    """حذف سجلات التسليم/الاستلام المحددة"""
    vehicle = Vehicle.query.get_or_404(vehicle_id)
    
    # التحقق من إدخال تأكيد الحذف
    confirmation = request.form.get('confirmation')
    if confirmation != 'تأكيد':
        flash('يجب كتابة كلمة "تأكيد" للمتابعة مع عملية الحذف!', 'danger')
        return redirect(url_for('vehicles.view', id=vehicle_id))
    
    # الحصول على معرفات السجلات المحددة
    record_ids = request.form.getlist('record_ids')
    if not record_ids:
        flash('لم يتم تحديد أي سجل للحذف!', 'warning')
        return redirect(url_for('vehicles.view', id=vehicle_id))
    
    # تحويل المعرفات إلى أرقام صحيحة
    record_ids = [int(id) for id in record_ids]
    
    # التحقق من أن السجلات تنتمي للسيارة المحددة
    records = VehicleHandover.query.filter(VehicleHandover.id.in_(record_ids)).all()
    for record in records:
        if record.vehicle_id != vehicle_id:
            flash('خطأ في البيانات المرسلة! بعض السجلات لا تنتمي لهذه السيارة.', 'danger')
            return redirect(url_for('vehicles.view', id=vehicle_id))
    
    # حذف السجلات
    for record in records:
        # تسجيل الإجراء قبل الحذف
        log_audit('delete', 'vehicle_handover', record.id, 
                 f'تم حذف سجل {"تسليم" if record.handover_type == "delivery" else "استلام"} للسيارة {vehicle.plate_number}')
        
        db.session.delete(record)
    
    db.session.commit()
    
    # رسالة نجاح
    if len(records) == 1:
        flash('تم حذف السجل بنجاح!', 'success')
    else:
        flash(f'تم حذف {len(records)} سجلات بنجاح!', 'success')
    
    return redirect(url_for('vehicles.view', id=vehicle_id))

@vehicles_bp.route('/handover/<int:id>/pdf')
@login_required
def handover_pdf(id):
    """إنشاء نموذج تسليم/استلام كملف PDF"""
    from flask import send_file, flash, redirect, url_for
    import io
    import os
    from datetime import datetime
    # استخدام مكتبة PDF المبسطة الجديدة
    from utils.simple_pdf_generator import create_vehicle_handover_pdf
    
    try:
        # التأكد من تحويل المعرف إلى عدد صحيح
        id = int(id) if not isinstance(id, int) else id
        
        # جلب البيانات
        handover = VehicleHandover.query.get_or_404(id)
        vehicle = Vehicle.query.get_or_404(handover.vehicle_id)
        
        # تجهيز البيانات
        handover_data = {
            'vehicle': {
                'plate_number': str(vehicle.plate_number),
                'make': str(vehicle.make),
                'model': str(vehicle.model),
                'year': int(vehicle.year),
                'color': str(vehicle.color)
            },
            'handover_type': 'تسليم' if handover.handover_type == 'delivery' else 'استلام',
            'handover_date': handover.handover_date.strftime('%Y-%m-%d'),
            'person_name': str(handover.person_name),
            'vehicle_condition': str(handover.vehicle_condition),
            'fuel_level': str(handover.fuel_level),
            'mileage': int(handover.mileage),
            'has_spare_tire': bool(handover.has_spare_tire),
            'has_fire_extinguisher': bool(handover.has_fire_extinguisher),
            'has_first_aid_kit': bool(handover.has_first_aid_kit),
            'has_warning_triangle': bool(handover.has_warning_triangle),
            'has_tools': bool(handover.has_tools),
            'notes': str(handover.notes) if handover.notes else "",
            'form_link': str(handover.form_link) if handover.form_link else ""
        }
        
        # إضافة معلومات المشرف إذا وجدت
        if hasattr(handover, 'supervisor_name') and handover.supervisor_name:
            handover_data['supervisor_name'] = str(handover.supervisor_name)
        
        # إنشاء ملف PDF باستخدام الدالة المبسطة
        # تمرير كائن البيانات مباشرة
        pdf_buffer = create_vehicle_handover_pdf(handover)
        
        # تحديد اسم الملف
        filename = f"handover_form_{vehicle.plate_number}.pdf"
        
        # إرسال الملف للمستخدم
        return send_file(
            pdf_buffer,
            download_name=filename,
            as_attachment=True,
            mimetype='application/pdf'
        )
    except Exception as e:
        # في حالة حدوث خطأ، عرض رسالة الخطأ والعودة إلى صفحة عرض السيارة
        flash(f'خطأ في إنشاء ملف PDF: {str(e)}', 'danger')
        return redirect(url_for('vehicles.view', id=vehicle.id if 'vehicle' in locals() else id))

# مسارات التقارير والإحصائيات
@vehicles_bp.route('/dashboard')
@login_required
def dashboard():
    """لوحة المعلومات والإحصائيات للسيارات"""
    # إجمالي عدد السيارات
    total_vehicles = Vehicle.query.count()
    
    # توزيع السيارات حسب الحالة
    status_stats = db.session.query(
        Vehicle.status, func.count(Vehicle.id)
    ).group_by(Vehicle.status).all()
    
    status_dict = {status: count for status, count in status_stats}
    
    # حساب قيمة الإيجارات الشهرية
    total_monthly_rent = db.session.query(
        func.sum(VehicleRental.monthly_cost)
    ).filter_by(is_active=True).scalar() or 0
    
    # السيارات في الورشة حالياً
    vehicles_in_workshop = VehicleWorkshop.query.filter(
        VehicleWorkshop.exit_date.is_(None)
    ).count()
    
    # تكاليف الصيانة الإجمالية (للسنة الحالية)
    current_year = datetime.now().year
    current_month = datetime.now().month
    
    yearly_maintenance_cost = db.session.query(
        func.sum(VehicleWorkshop.cost)
    ).filter(
        extract('year', VehicleWorkshop.entry_date) == current_year
    ).scalar() or 0
    
    # تكاليف الصيانة الشهرية (للأشهر الستة الماضية)
    monthly_costs = []
    for i in range(6):
        month = current_month - i
        year = current_year
        if month <= 0:
            month += 12
            year -= 1
        
        month_cost = db.session.query(
            func.sum(VehicleWorkshop.cost)
        ).filter(
            extract('year', VehicleWorkshop.entry_date) == year,
            extract('month', VehicleWorkshop.entry_date) == month
        ).scalar() or 0
        
        month_name = [
            'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
            'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
        ][month - 1]
        
        monthly_costs.append({
            'month': month_name,
            'cost': month_cost
        })
    
    # عكس ترتيب القائمة لعرض الأشهر من الأقدم إلى الأحدث
    monthly_costs.reverse()
    
    # قائمة التنبيهات
    alerts = []
    
    # تنبيهات السيارات في الورشة لفترة طويلة (أكثر من أسبوعين)
    long_workshop_stays = VehicleWorkshop.query.filter(
        VehicleWorkshop.exit_date.is_(None),
        VehicleWorkshop.entry_date <= (datetime.now().date() - timedelta(days=14))
    ).all()
    
    for stay in long_workshop_stays:
        days = (datetime.now().date() - stay.entry_date).days
        vehicle = Vehicle.query.get(stay.vehicle_id)
        alerts.append({
            'type': 'workshop',
            'message': f'السيارة {vehicle.plate_number} في الورشة منذ {days} يوم',
            'vehicle_id': vehicle.id,
            'plate_number': vehicle.plate_number,
            'make': vehicle.make,
            'model': vehicle.model
        })
    
    # تنبيهات الإيجارات التي ستنتهي قريباً (خلال أسبوع)
    ending_rentals = VehicleRental.query.filter(
        VehicleRental.is_active == True,
        VehicleRental.end_date.isnot(None),
        VehicleRental.end_date <= (datetime.now().date() + timedelta(days=7)),
        VehicleRental.end_date >= datetime.now().date()
    ).all()
    
    for rental in ending_rentals:
        days = (rental.end_date - datetime.now().date()).days
        vehicle = Vehicle.query.get(rental.vehicle_id)
        alerts.append({
            'type': 'rental',
            'message': f'إيجار السيارة {vehicle.plate_number} سينتهي خلال {days} يوم',
            'vehicle_id': vehicle.id,
            'plate_number': vehicle.plate_number,
            'make': vehicle.make,
            'model': vehicle.model
        })
    
    # استرجاع السيارات ذات الوثائق المنتهية
    today = datetime.now().date()
    
    # السيارات ذات استمارة منتهية
    expired_registration_vehicles = Vehicle.query.filter(
        Vehicle.registration_expiry_date.isnot(None),
        Vehicle.registration_expiry_date < today
    ).order_by(Vehicle.registration_expiry_date).all()
    
    # السيارات ذات فحص دوري منتهي
    expired_inspection_vehicles = Vehicle.query.filter(
        Vehicle.inspection_expiry_date.isnot(None),
        Vehicle.inspection_expiry_date < today
    ).order_by(Vehicle.inspection_expiry_date).all()
    
    # السيارات ذات تفويض منتهي
    expired_authorization_vehicles = Vehicle.query.filter(
        Vehicle.authorization_expiry_date.isnot(None),
        Vehicle.authorization_expiry_date < today
    ).order_by(Vehicle.authorization_expiry_date).all()
    
    # إعداد بيانات حالة السيارات بالتنسيق المطلوب في القالب
    status_counts = {
        'available': status_dict.get('available', 0),
        'rented': status_dict.get('rented', 0),
        'in_project': status_dict.get('in_project', 0),
        'in_workshop': status_dict.get('in_workshop', 0),
        'accident': status_dict.get('accident', 0)
    }
    
    # تجميع الإحصائيات في كائن واحد
    stats = {
        'total_vehicles': total_vehicles,
        'status_stats': status_dict,
        'status_counts': status_counts,  # إضافة حالات السيارات بالتنسيق المناسب للقالب
        'total_monthly_rent': total_monthly_rent,
        'total_rental_cost': total_monthly_rent,  # نفس القيمة تستخدم في القالب باسم مختلف
        'vehicles_in_workshop': vehicles_in_workshop,
        'yearly_maintenance_cost': yearly_maintenance_cost,
        'new_vehicles_last_month': Vehicle.query.filter(
            Vehicle.created_at >= (datetime.now() - timedelta(days=30))
        ).count(),  # عدد السيارات المضافة في الشهر الماضي
        
        # تكاليف الورشة للشهر الحالي
        'workshop_cost_current_month': db.session.query(
            func.sum(VehicleWorkshop.cost)
        ).filter(
            extract('year', VehicleWorkshop.entry_date) == current_year,
            extract('month', VehicleWorkshop.entry_date) == current_month
        ).scalar() or 0,
        
        # عدد السيارات في المشاريع
        'vehicles_in_projects': Vehicle.query.filter_by(status='in_project').count(),
        
        # عدد المشاريع النشطة
        'project_assignments_count': db.session.query(
            func.count(func.distinct(VehicleProject.project_name))
        ).filter_by(is_active=True).scalar() or 0
    }
    
    # Datos para el gráfico de costos de alquiler
    rental_cost_data = {
        'labels': [],  # Nombres de meses
        'data_values': []   # Valores de costos - renombrado para evitar conflicto con el método values()
    }
    
    # Datos para el gráfico de costos de mantenimiento
    maintenance_cost_data = {
        'labels': [],  # Nombres de meses
        'data_values': []   # Valores de costos - renombrado para evitar conflicto con el método values()
    }
    
    # Obtener datos de los últimos 6 meses para los gráficos
    current_month = datetime.now().month
    current_year = datetime.now().year
    
    for i in range(5, -1, -1):
        month_num = (current_month - i) % 12
        if month_num == 0:
            month_num = 12
        year = current_year - 1 if current_month - i <= 0 else current_year
        
        month_name = {
            1: 'يناير', 2: 'فبراير', 3: 'مارس', 4: 'أبريل', 5: 'مايو', 6: 'يونيو',
            7: 'يوليو', 8: 'أغسطس', 9: 'سبتمبر', 10: 'أكتوبر', 11: 'نوفمبر', 12: 'ديسمبر'
        }[month_num]
        
        month_label = f"{month_name} {year}"
        
        # Añadir datos para ambos gráficos
        rental_cost_data['labels'].append(month_label)
        rental_cost_data['data_values'].append(0)  # Valor predeterminado 0, se puede reemplazar con datos reales
        
        maintenance_cost_data['labels'].append(month_label)
        maintenance_cost_data['data_values'].append(0)  # Valor predeterminado 0, se puede reemplazar con datos reales
    
    return render_template(
        'vehicles/dashboard.html',
        stats=stats,
        monthly_costs=monthly_costs,
        alerts=alerts,
        rental_cost_data=rental_cost_data,
        maintenance_cost_data=maintenance_cost_data,
        expired_registration_vehicles=expired_registration_vehicles,
        expired_inspection_vehicles=expired_inspection_vehicles,
        expired_authorization_vehicles=expired_authorization_vehicles,
        today=today
    )

@vehicles_bp.route('/reports')
@login_required
def reports():
    """صفحة تقارير السيارات"""
    # توزيع السيارات حسب الشركة المصنعة
    make_stats = db.session.query(
        Vehicle.make, func.count(Vehicle.id)
    ).group_by(Vehicle.make).all()
    
    # توزيع السيارات حسب سنة الصنع
    year_stats = db.session.query(
        Vehicle.year, func.count(Vehicle.id)
    ).group_by(Vehicle.year).order_by(Vehicle.year).all()
    
    # إحصائيات الورشة
    workshop_reason_stats = db.session.query(
        VehicleWorkshop.reason, func.count(VehicleWorkshop.id)
    ).group_by(VehicleWorkshop.reason).all()
    
    # إجمالي تكاليف الصيانة لكل سيارة (أعلى 10 سيارات)
    top_maintenance_costs = db.session.query(
        Vehicle.plate_number, Vehicle.make, Vehicle.model, 
        func.sum(VehicleWorkshop.cost).label('total_cost')
    ).join(
        VehicleWorkshop, Vehicle.id == VehicleWorkshop.vehicle_id
    ).group_by(
        Vehicle.id, Vehicle.plate_number, Vehicle.make, Vehicle.model
    ).order_by(
        func.sum(VehicleWorkshop.cost).desc()
    ).limit(10).all()
    
    return render_template(
        'vehicles/reports.html',
        make_stats=make_stats,
        year_stats=year_stats,
        workshop_reason_stats=workshop_reason_stats,
        top_maintenance_costs=top_maintenance_costs
    )

@vehicles_bp.route('/detailed')
@login_required
def detailed_list():
    """قائمة تفصيلية للسيارات مع معلومات إضافية لكل سيارة على حدة"""
    # إعداد قيم التصفية
    status = request.args.get('status')
    make = request.args.get('make')
    year = request.args.get('year')
    project = request.args.get('project')
    location = request.args.get('location')
    sort = request.args.get('sort', 'plate_number')
    search = request.args.get('search', '')
    
    # استعلام قاعدة البيانات مع التصفية
    query = Vehicle.query
    
    if status:
        query = query.filter(Vehicle.status == status)
    if make:
        query = query.filter(Vehicle.make == make)
    if year:
        query = query.filter(Vehicle.year == int(year))
    if search:
        query = query.filter(
            or_(
                Vehicle.plate_number.ilike(f'%{search}%'),
                Vehicle.make.ilike(f'%{search}%'),
                Vehicle.model.ilike(f'%{search}%'),
                Vehicle.color.ilike(f'%{search}%')
            )
        )
    
    # فلترة حسب المشروع
    if project:
        vehicle_ids = db.session.query(VehicleProject.vehicle_id).filter_by(
            project_name=project, is_active=True
        ).all()
        vehicle_ids = [v[0] for v in vehicle_ids]
        query = query.filter(Vehicle.id.in_(vehicle_ids))
    
    # فلترة حسب الموقع (المنطقة)
    if location:
        vehicle_ids = db.session.query(VehicleProject.vehicle_id).filter_by(
            location=location, is_active=True
        ).all()
        vehicle_ids = [v[0] for v in vehicle_ids]
        query = query.filter(Vehicle.id.in_(vehicle_ids))
    
    # ترتيب النتائج
    if sort == 'make':
        query = query.order_by(Vehicle.make, Vehicle.model)
    elif sort == 'year':
        query = query.order_by(Vehicle.year.desc())
    elif sort == 'status':
        query = query.order_by(Vehicle.status)
    elif sort == 'created_at':
        query = query.order_by(Vehicle.created_at.desc())
    else:
        query = query.order_by(Vehicle.plate_number)
    
    # الترقيم
    page = request.args.get('page', 1, type=int)
    pagination = query.paginate(page=page, per_page=20, error_out=False)
    vehicles = pagination.items
    
    # استخراج معلومات إضافية لكل سيارة
    for vehicle in vehicles:
        # معلومات الإيجار النشط
        vehicle.active_rental = VehicleRental.query.filter_by(
            vehicle_id=vehicle.id, is_active=True
        ).first()
        
        # معلومات آخر دخول للورشة
        vehicle.latest_workshop = VehicleWorkshop.query.filter_by(
            vehicle_id=vehicle.id
        ).order_by(VehicleWorkshop.entry_date.desc()).first()
        
        # معلومات المشروع الحالي
        vehicle.active_project = VehicleProject.query.filter_by(
            vehicle_id=vehicle.id, is_active=True
        ).first()
    
    # استخراج قوائم الفلاتر
    makes = db.session.query(Vehicle.make).distinct().order_by(Vehicle.make).all()
    makes = [make[0] for make in makes]
    
    years = db.session.query(Vehicle.year).distinct().order_by(Vehicle.year.desc()).all()
    years = [year[0] for year in years]
    
    # استخراج قائمة المشاريع النشطة
    projects = db.session.query(VehicleProject.project_name).filter_by(
        is_active=True
    ).distinct().order_by(VehicleProject.project_name).all()
    projects = [project[0] for project in projects]
    
    # استخراج قائمة المواقع (المناطق)
    locations = db.session.query(VehicleProject.location).distinct().order_by(
        VehicleProject.location
    ).all()
    locations = [location[0] for location in locations]
    
    return render_template(
        'vehicles/detailed_list.html',
        vehicles=vehicles,
        pagination=pagination,
        makes=makes,
        years=years,
        projects=projects,
        locations=locations,
        total_count=Vehicle.query.count(),
        request=request
    )

@vehicles_bp.route('/report/export/excel')
@login_required
def export_vehicles_excel():
    """تصدير بيانات السيارات إلى ملف Excel"""
    import io
    import pandas as pd
    from flask import send_file
    import datetime
    
    status_filter = request.args.get('status', '')
    make_filter = request.args.get('make', '')
    
    # قاعدة الاستعلام الأساسية
    query = Vehicle.query
    
    # إضافة التصفية حسب الحالة إذا تم تحديدها
    if status_filter:
        query = query.filter(Vehicle.status == status_filter)
    
    # إضافة التصفية حسب الشركة المصنعة إذا تم تحديدها
    if make_filter:
        query = query.filter(Vehicle.make == make_filter)
    
    # الحصول على قائمة السيارات
    vehicles = query.order_by(Vehicle.status, Vehicle.plate_number).all()
    
    # تحويل حالة السيارة إلى نص مقروء بالعربية
    status_map = {
        'available': 'متاحة',
        'rented': 'مؤجرة',
        'in_project': 'في المشروع',
        'in_workshop': 'في الورشة',
        'accident': 'حادث'
    }
    
    # إنشاء قائمة بالبيانات
    vehicle_data = []
    for vehicle in vehicles:
        # حساب تكاليف الصيانة الإجمالية
        total_maintenance_cost = db.session.query(
            func.sum(VehicleWorkshop.cost)
        ).filter(
            VehicleWorkshop.vehicle_id == vehicle.id
        ).scalar() or 0
        
        # الحصول على معلومات الإيجار النشط
        active_rental = VehicleRental.query.filter_by(
            vehicle_id=vehicle.id, is_active=True
        ).first()
        
        # الحصول على معلومات المشروع النشط
        active_project = VehicleProject.query.filter_by(
            vehicle_id=vehicle.id, is_active=True
        ).first()
        
        vehicle_data.append({
            'رقم اللوحة': vehicle.plate_number,
            'الشركة المصنعة': vehicle.make,
            'الموديل': vehicle.model,
            'السنة': vehicle.year,
            'اللون': vehicle.color,
            'الحالة': status_map.get(vehicle.status, vehicle.status),
            'تكاليف الصيانة الإجمالية': total_maintenance_cost,
            'المؤجر': active_rental.lessor_name if active_rental else '',
            'تكلفة الإيجار الشهرية': active_rental.monthly_cost if active_rental else 0,
            'المشروع': active_project.project_name if active_project else '',
            'الموقع': active_project.location if active_project else '',
            'ملاحظات': vehicle.notes or ''
        })
    
    # إنشاء DataFrame من البيانات
    df = pd.DataFrame(vehicle_data)
    
    # إنشاء ملف Excel في الذاكرة
    output = io.BytesIO()
    
    # استخدام ExcelWriter مع خيارات لتحسين المظهر
    with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
        df.to_excel(writer, sheet_name='بيانات السيارات', index=False)
        
        # الحصول على ورقة العمل وworkbook للتنسيق
        workbook = writer.book
        worksheet = writer.sheets['بيانات السيارات']
        
        # تنسيق الخلايا
        header_format = workbook.add_format({
            'bold': True,
            'text_wrap': True,
            'valign': 'top',
            'fg_color': '#D7E4BC',
            'border': 1
        })
        
        # تنسيق عناوين الأعمدة
        for col_num, value in enumerate(df.columns.values):
            worksheet.write(0, col_num, value, header_format)
            # ضبط عرض العمود
            worksheet.set_column(col_num, col_num, 15)
    
    # التحضير لإرسال الملف
    output.seek(0)
    
    # اسم الملف بالتاريخ الحالي
    today = datetime.datetime.now().strftime('%Y-%m-%d')
    filename = f"تقرير_السيارات_{today}.xlsx"
    
    # إرسال الملف كمرفق للتنزيل
    return send_file(
        output,
        download_name=filename,
        as_attachment=True,
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )


# مسار عرض تفاصيل سجل الورشة
@vehicles_bp.route('/workshop-details/<int:workshop_id>')
@login_required
def workshop_details(workshop_id):
    """عرض تفاصيل سجل ورشة في صفحة منفصلة"""
    # الحصول على سجل الورشة
    record = VehicleWorkshop.query.get_or_404(workshop_id)
    vehicle = Vehicle.query.get_or_404(record.vehicle_id)
    
    # تنسيق التواريخ
    record.formatted_entry_date = format_date_arabic(record.entry_date)
    if record.exit_date:
        record.formatted_exit_date = format_date_arabic(record.exit_date)
    
    # استرجاع الصور المرتبطة بسجل الورشة
    images = VehicleWorkshopImage.query.filter_by(workshop_record_id=workshop_id).all()
    record.images = images
    
    # تسجيل الوقت الحالي
    current_date = format_date_arabic(datetime.now().date())
    
    return render_template(
        'vehicles/workshop_details.html',
        vehicle=vehicle,
        record=record,
        current_date=current_date
    )


# مسارات حذف سجلات الورشة
@vehicles_bp.route('/workshop/confirm-delete/<int:id>')
@login_required
def confirm_delete_workshop(id):
    """تأكيد حذف سجل ورشة"""
    record = VehicleWorkshop.query.get_or_404(id)
    vehicle = Vehicle.query.get_or_404(record.vehicle_id)
    
    # تنسيق التواريخ
    record.formatted_entry_date = format_date_arabic(record.entry_date)
    if record.exit_date:
        record.formatted_exit_date = format_date_arabic(record.exit_date)
    
    return render_template(
        'vehicles/confirm_delete_workshop.html',
        record=record,
        vehicle=vehicle
    )


@vehicles_bp.route('/workshop/delete/<int:id>', methods=['POST'])
@login_required
def delete_workshop(id):
    """حذف سجل ورشة"""
    record = VehicleWorkshop.query.get_or_404(id)
    vehicle_id = record.vehicle_id
    
    # التحقق من وجود كلمة التأكيد الصحيحة
    confirmation = request.form.get('confirmation', '')
    if confirmation != 'تأكيد':
        flash('كلمة التأكيد غير صحيحة. لم يتم حذف السجل.', 'danger')
        return redirect(url_for('vehicles.confirm_delete_workshop', id=id))
    
    # تسجيل الإجراء قبل الحذف
    log_audit('delete', 'VehicleWorkshop', id, f'تم حذف سجل الورشة للسيارة رقم {vehicle_id}')
    
    try:
        # حذف سجل الورشة سيحذف تلقائياً جميع الصور المرتبطة به بفضل cascade='all, delete-orphan'
        db.session.delete(record)
        db.session.commit()
        flash('تم حذف سجل الورشة بنجاح', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'حدث خطأ أثناء حذف سجل الورشة: {str(e)}', 'danger')
    
    return redirect(url_for('vehicles.view', id=vehicle_id))


# مسارات التصدير والمشاركة
@vehicles_bp.route('/<int:id>/export/pdf')
@login_required
def export_vehicle_to_pdf(id):
    """تصدير بيانات السيارة إلى ملف PDF"""
    vehicle = Vehicle.query.get_or_404(id)
    workshop_records = VehicleWorkshop.query.filter_by(vehicle_id=id).order_by(VehicleWorkshop.entry_date.desc()).all()
    rental_records = VehicleRental.query.filter_by(vehicle_id=id).order_by(VehicleRental.start_date.desc()).all()
    
    # إنشاء ملف PDF
    pdf_buffer = export_vehicle_pdf(vehicle, workshop_records, rental_records)
    
    # تسجيل الإجراء
    log_audit('export', 'vehicle', id, f'تم تصدير بيانات السيارة {vehicle.plate_number} إلى PDF')
    
    return send_file(
        pdf_buffer,
        download_name=f'vehicle_{vehicle.plate_number}_{datetime.now().strftime("%Y%m%d")}.pdf',
        as_attachment=True,
        mimetype='application/pdf'
    )


@vehicles_bp.route('/<int:id>/export/workshop/pdf')
@login_required
def export_workshop_to_pdf(id):
    """تصدير سجلات الورشة للسيارة إلى ملف PDF مع دعم كامل للغة العربية (النسخة المحسنة)"""
    try:
        # جلب بيانات المركبة
        vehicle = Vehicle.query.get_or_404(id)
        
        # جلب سجلات دخول الورشة
        workshop_records = VehicleWorkshop.query.filter_by(vehicle_id=id).order_by(
            VehicleWorkshop.entry_date.desc()
        ).all()
        
        # التحقق من وجود سجلات
        if not workshop_records:
            flash('لا توجد سجلات ورشة لهذه المركبة!', 'warning')
            return redirect(url_for('vehicles.view', id=id))
        
        # إنشاء تقرير PDF باستخدام المولد الإنجليزي
        from utils.english_workshop_pdf import generate_workshop_pdf
        pdf_data = generate_workshop_pdf(vehicle, workshop_records)
        pdf_buffer = io.BytesIO(pdf_data)
        
        # اسم الملف
        filename = f"workshop_report_{vehicle.plate_number}_{datetime.now().strftime('%Y%m%d')}.pdf"
        
        # تسجيل الإجراء
        log_audit('export', 'vehicle_workshop', id, f'تم تصدير سجلات ورشة السيارة {vehicle.plate_number} إلى PDF بدعم كامل للغة العربية')
        
        # إرسال الملف
        return send_file(
            pdf_buffer,
            download_name=filename,
            as_attachment=True,
            mimetype='application/pdf'
        )
    except Exception as e:
        import logging
        logging.error(f"خطأ في إنشاء تقرير الورشة: {str(e)}")
        flash(f'حدث خطأ أثناء إنشاء التقرير: {str(e)}', 'danger')
        return redirect(url_for('vehicles.view', id=id))


@vehicles_bp.route('/<int:id>/export/excel')
@login_required
def export_vehicle_to_excel(id):
    """تصدير بيانات السيارة إلى ملف Excel"""
    vehicle = Vehicle.query.get_or_404(id)
    workshop_records = VehicleWorkshop.query.filter_by(vehicle_id=id).order_by(VehicleWorkshop.entry_date.desc()).all()
    rental_records = VehicleRental.query.filter_by(vehicle_id=id).order_by(VehicleRental.start_date.desc()).all()
    
    # إنشاء ملف Excel
    excel_buffer = export_vehicle_excel(vehicle, workshop_records, rental_records)
    
    # تسجيل الإجراء
    log_audit('export', 'vehicle', id, f'تم تصدير بيانات السيارة {vehicle.plate_number} إلى Excel')
    
    return send_file(
        excel_buffer,
        download_name=f'vehicle_{vehicle.plate_number}_{datetime.now().strftime("%Y%m%d")}.xlsx',
        as_attachment=True,
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )


@vehicles_bp.route('/<int:id>/export/workshop/excel')
@login_required
def export_workshop_to_excel(id):
    """تصدير سجلات الورشة للسيارة إلى ملف Excel"""
    vehicle = Vehicle.query.get_or_404(id)
    workshop_records = VehicleWorkshop.query.filter_by(vehicle_id=id).order_by(VehicleWorkshop.entry_date.desc()).all()
    
    # إنشاء ملف Excel
    excel_buffer = export_workshop_records_excel(vehicle, workshop_records)
    
    # تسجيل الإجراء
    log_audit('export', 'vehicle_workshop', id, f'تم تصدير سجلات ورشة السيارة {vehicle.plate_number} إلى Excel')
    
    return send_file(
        excel_buffer,
        download_name=f'vehicle_workshop_{vehicle.plate_number}_{datetime.now().strftime("%Y%m%d")}.xlsx',
        as_attachment=True,
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )


@vehicles_bp.route('/<int:id>/share/workshop')
@login_required
def share_workshop_options(id):
    """خيارات مشاركة سجلات الورشة للسيارة"""
    vehicle = Vehicle.query.get_or_404(id)
    
    # إنشاء روابط التصدير والمشاركة
    app_url = request.host_url.rstrip('/')
    pdf_url = f"{app_url}{url_for('vehicles.export_workshop_to_pdf', id=id)}"
    excel_url = f"{app_url}{url_for('vehicles.export_workshop_to_excel', id=id)}"
    
    # إنشاء روابط المشاركة
    whatsapp_text = f"سجلات ورشة السيارة: {vehicle.plate_number} - {vehicle.make} {vehicle.model}"
    whatsapp_url = f"https://wa.me/?text={urllib.parse.quote(whatsapp_text)} PDF: {urllib.parse.quote(pdf_url)}"
    
    email_subject = f"سجلات ورشة السيارة: {vehicle.plate_number}"
    email_body = f"مرفق سجلات ورشة السيارة: {vehicle.plate_number} - {vehicle.make} {vehicle.model}\n\nرابط تحميل PDF: {pdf_url}\n\nرابط تحميل Excel: {excel_url}"
    email_url = f"mailto:?subject={urllib.parse.quote(email_subject)}&body={urllib.parse.quote(email_body)}"
    
    return render_template(
        'vehicles/share_workshop.html',
        vehicle=vehicle,
        pdf_url=pdf_url,
        excel_url=excel_url,
        whatsapp_url=whatsapp_url,
        email_url=email_url
    )


@vehicles_bp.route('/<int:id>/print/workshop')
@login_required
def print_workshop_records(id):
    """عرض سجلات الورشة للطباعة"""
    vehicle = Vehicle.query.get_or_404(id)
    workshop_records = VehicleWorkshop.query.filter_by(vehicle_id=id).order_by(VehicleWorkshop.entry_date.desc()).all()
    
    # تنسيق التواريخ
    for record in workshop_records:
        record.formatted_entry_date = format_date_arabic(record.entry_date)
        if record.exit_date:
            record.formatted_exit_date = format_date_arabic(record.exit_date)
    
    # حساب تكلفة الإصلاحات الإجمالية
    total_maintenance_cost = db.session.query(func.sum(VehicleWorkshop.cost)).filter_by(vehicle_id=id).scalar() or 0
    
    # حساب عدد الأيام في الورشة
    days_in_workshop = 0
    for record in workshop_records:
        if record.exit_date:
            days_in_workshop += (record.exit_date - record.entry_date).days
        else:
            days_in_workshop += (datetime.now().date() - record.entry_date).days
    
    return render_template(
        'vehicles/print_workshop.html',
        vehicle=vehicle,
        workshop_records=workshop_records,
        total_maintenance_cost=total_maintenance_cost,
        days_in_workshop=days_in_workshop,
        current_date=format_date_arabic(datetime.now().date())
    )


# إنشاء تقرير شامل للسيارة (PDF) - محتفظ به ولكن قد لا يعمل بشكل صحيح مع النصوص العربية
@vehicles_bp.route('/vehicle-report-pdf/<int:id>')
@login_required
def generate_vehicle_report_pdf(id):
    """إنشاء تقرير شامل للسيارة بصيغة PDF"""
    from flask import send_file, flash, redirect, url_for, make_response
    import io
    
    try:
        # الحصول على بيانات المركبة
        vehicle = Vehicle.query.get_or_404(id)
        
        # الحصول على بيانات الإيجار النشط
        rental = VehicleRental.query.filter_by(vehicle_id=id, is_active=True).first()
        
        # الحصول على سجلات الورشة
        workshop_records = VehicleWorkshop.query.filter_by(vehicle_id=id).order_by(
            VehicleWorkshop.entry_date.desc()
        ).all()
        
        # هذا الموديل قد لا يكون موجودًا، لذلك سنتجاهله الآن
        documents = None
        
        # إنشاء التقرير الشامل
        pdf_bytes = generate_complete_vehicle_report(
            vehicle, 
            rental=rental, 
            workshop_records=workshop_records,
            documents=documents
        )
        
        # إرسال الملف للمستخدم
        buffer = io.BytesIO(pdf_bytes)
        response = make_response(send_file(
            buffer,
            download_name=f'تقرير_شامل_{vehicle.plate_number}.pdf',
            mimetype='application/pdf',
            as_attachment=True
        ))
        
        # تسجيل الإجراء
        log_audit('generate_report', 'vehicle', id, f'تم إنشاء تقرير شامل للسيارة (PDF): {vehicle.plate_number}')
        
        return response
        
    except Exception as e:
        flash(f'حدث خطأ أثناء إنشاء التقرير PDF: {str(e)}', 'danger')
        return redirect(url_for('vehicles.view', id=id))


# مسارات إدارة الفحص الدوري
@vehicles_bp.route('/<int:id>/inspections', methods=['GET'])
@login_required
def vehicle_inspections(id):
    """عرض سجلات الفحص الدوري لسيارة محددة"""
    vehicle = Vehicle.query.get_or_404(id)
    inspections = VehiclePeriodicInspection.query.filter_by(vehicle_id=id).order_by(VehiclePeriodicInspection.inspection_date.desc()).all()
    
    # تنسيق التواريخ
    for inspection in inspections:
        inspection.formatted_inspection_date = format_date_arabic(inspection.inspection_date)
        inspection.formatted_expiry_date = format_date_arabic(inspection.expiry_date)
    
    return render_template(
        'vehicles/inspections.html',
        vehicle=vehicle,
        inspections=inspections,
        inspection_types=INSPECTION_TYPE_CHOICES,
        inspection_statuses=INSPECTION_STATUS_CHOICES
    )

@vehicles_bp.route('/<int:id>/inspections/create', methods=['GET', 'POST'])
@login_required
def create_inspection(id):
    """إضافة سجل فحص دوري جديد"""
    vehicle = Vehicle.query.get_or_404(id)
    
    if request.method == 'POST':
        inspection_date = datetime.strptime(request.form.get('inspection_date'), '%Y-%m-%d').date()
        expiry_date = datetime.strptime(request.form.get('expiry_date'), '%Y-%m-%d').date()
        inspection_center = request.form.get('inspection_center')
        supervisor_name = request.form.get('supervisor_name')
        result = request.form.get('result')
        inspection_status = 'valid'  # الحالة الافتراضية ساري
        cost = float(request.form.get('cost') or 0)
        results = request.form.get('results')
        recommendations = request.form.get('recommendations')
        notes = request.form.get('notes')
        
        # حفظ شهادة الفحص إذا تم تحميلها
        certificate_file = None
        if 'certificate_file' in request.files and request.files['certificate_file']:
            certificate_file = save_image(request.files['certificate_file'], 'inspections')
        
        # إنشاء سجل فحص جديد
        inspection = VehiclePeriodicInspection(
            vehicle_id=id,
            inspection_date=inspection_date,
            expiry_date=expiry_date,
            inspection_center=inspection_center,
            supervisor_name=supervisor_name,
            result=result,
            # القيم القديمة للتوافق مع قاعدة البيانات
            inspection_number=inspection_center,
            inspector_name=supervisor_name,
            inspection_type=result,
            inspection_status=inspection_status,
            cost=cost,
            results=results,
            recommendations=recommendations,
            certificate_file=certificate_file,
            notes=notes
        )
        
        db.session.add(inspection)
        db.session.commit()
        
        # تسجيل الإجراء
        log_audit('create', 'vehicle_inspection', inspection.id, f'تم إضافة سجل فحص دوري للسيارة: {vehicle.plate_number}')
        
        flash('تم إضافة سجل الفحص الدوري بنجاح!', 'success')
        return redirect(url_for('vehicles.vehicle_inspections', id=id))
    
    return render_template(
        'vehicles/inspection_create.html',
        vehicle=vehicle,
        inspection_types=INSPECTION_TYPE_CHOICES
    )

@vehicles_bp.route('/inspection/<int:id>/edit', methods=['GET', 'POST'])
@login_required
def edit_inspection(id):
    """تعديل سجل فحص دوري"""
    inspection = VehiclePeriodicInspection.query.get_or_404(id)
    vehicle = Vehicle.query.get_or_404(inspection.vehicle_id)
    
    if request.method == 'POST':
        inspection.inspection_date = datetime.strptime(request.form.get('inspection_date'), '%Y-%m-%d').date()
        inspection.expiry_date = datetime.strptime(request.form.get('expiry_date'), '%Y-%m-%d').date()
        inspection.inspection_center = request.form.get('inspection_center')
        inspection.supervisor_name = request.form.get('supervisor_name')
        inspection.result = request.form.get('result')
        
        # حفظ القيم القديمة أيضًا للتوافق مع قاعدة البيانات
        inspection.inspection_number = request.form.get('inspection_center')
        inspection.inspector_name = request.form.get('supervisor_name')
        inspection.inspection_type = request.form.get('result')
        
        inspection.inspection_status = request.form.get('inspection_status')
        inspection.cost = float(request.form.get('cost') or 0)
        inspection.results = request.form.get('results')
        inspection.recommendations = request.form.get('recommendations')
        inspection.notes = request.form.get('notes')
        inspection.updated_at = datetime.utcnow()
        
        # حفظ شهادة الفحص الجديدة إذا تم تحميلها
        if 'certificate_file' in request.files and request.files['certificate_file']:
            inspection.certificate_file = save_image(request.files['certificate_file'], 'inspections')
        
        db.session.commit()
        
        # تسجيل الإجراء
        log_audit('update', 'vehicle_inspection', inspection.id, f'تم تعديل سجل فحص دوري للسيارة: {vehicle.plate_number}')
        
        flash('تم تعديل سجل الفحص الدوري بنجاح!', 'success')
        return redirect(url_for('vehicles.vehicle_inspections', id=vehicle.id))
    
    return render_template(
        'vehicles/inspection_edit.html',
        inspection=inspection,
        vehicle=vehicle,
        inspection_types=INSPECTION_TYPE_CHOICES,
        inspection_statuses=INSPECTION_STATUS_CHOICES
    )

@vehicles_bp.route('/inspection/<int:id>/confirm-delete')
@login_required
def confirm_delete_inspection(id):
    """عرض صفحة تأكيد حذف سجل فحص دوري"""
    inspection = VehiclePeriodicInspection.query.get_or_404(id)
    vehicle = Vehicle.query.get_or_404(inspection.vehicle_id)
    
    # تنسيق التاريخ
    inspection.formatted_inspection_date = format_date_arabic(inspection.inspection_date)
    
    return render_template(
        'vehicles/confirm_delete_inspection.html',
        inspection=inspection,
        vehicle=vehicle
    )

@vehicles_bp.route('/inspection/<int:id>/delete', methods=['POST'])
@login_required
def delete_inspection(id):
    """حذف سجل فحص دوري"""
    inspection = VehiclePeriodicInspection.query.get_or_404(id)
    vehicle_id = inspection.vehicle_id
    vehicle = Vehicle.query.get_or_404(vehicle_id)
    
    # تسجيل الإجراء قبل الحذف
    log_audit('delete', 'vehicle_inspection', id, f'تم حذف سجل فحص دوري للسيارة: {vehicle.plate_number}')
    
    db.session.delete(inspection)
    db.session.commit()
    
    flash('تم حذف سجل الفحص الدوري بنجاح!', 'success')
    return redirect(url_for('vehicles.vehicle_inspections', id=vehicle_id))

# مسارات إدارة فحص السلامة
@vehicles_bp.route('/<int:id>/safety-checks', methods=['GET'])
@login_required
def vehicle_safety_checks(id):
    """عرض سجلات فحص السلامة لسيارة محددة"""
    vehicle = Vehicle.query.get_or_404(id)
    checks = VehicleSafetyCheck.query.filter_by(vehicle_id=id).order_by(VehicleSafetyCheck.check_date.desc()).all()
    
    # تنسيق التواريخ
    for check in checks:
        check.formatted_check_date = format_date_arabic(check.check_date)
    
    return render_template(
        'vehicles/safety_checks.html',
        vehicle=vehicle,
        checks=checks,
        check_types=SAFETY_CHECK_TYPE_CHOICES,
        check_statuses=SAFETY_CHECK_STATUS_CHOICES
    )

@vehicles_bp.route('/<int:id>/safety-checks/create', methods=['GET', 'POST'])
@login_required
def create_safety_check(id):
    """إضافة سجل فحص سلامة جديد"""
    vehicle = Vehicle.query.get_or_404(id)
    
    # الحصول على قائمة السائقين والمشرفين
    supervisors = Employee.query.filter(Employee.job_title.contains('مشرف')).all()
    
    if request.method == 'POST':
        check_date = datetime.strptime(request.form.get('check_date'), '%Y-%m-%d').date()
        check_type = request.form.get('check_type')
        
        # معلومات السائق
        driver_id = request.form.get('driver_id')
        driver_name = request.form.get('driver_name')
        # تحويل قيمة فارغة إلى None
        if not driver_id or driver_id == '':
            driver_id = None
        else:
            driver = Employee.query.get(driver_id)
            if driver:
                driver_name = driver.name
        
        # معلومات المشرف
        supervisor_id = request.form.get('supervisor_id')
        supervisor_name = request.form.get('supervisor_name')
        # تحويل قيمة فارغة إلى None
        if not supervisor_id or supervisor_id == '':
            supervisor_id = None
        else:
            supervisor = Employee.query.get(supervisor_id)
            if supervisor:
                supervisor_name = supervisor.name
        
        status = request.form.get('status')
        check_form_link = request.form.get('check_form_link')
        issues_found = bool(request.form.get('issues_found'))
        issues_description = request.form.get('issues_description')
        actions_taken = request.form.get('actions_taken')
        notes = request.form.get('notes')
        
        # إنشاء سجل فحص سلامة جديد
        safety_check = VehicleSafetyCheck(
            vehicle_id=id,
            check_date=check_date,
            check_type=check_type,
            driver_id=driver_id,
            driver_name=driver_name,
            supervisor_id=supervisor_id,
            supervisor_name=supervisor_name,
            status=status,
            check_form_link=check_form_link,
            issues_found=issues_found,
            issues_description=issues_description,
            actions_taken=actions_taken,
            notes=notes
        )
        
        db.session.add(safety_check)
        db.session.commit()
        
        # تسجيل الإجراء
        log_audit('create', 'vehicle_safety_check', safety_check.id, f'تم إضافة سجل فحص سلامة للسيارة: {vehicle.plate_number}')
        
        flash('تم إضافة سجل فحص السلامة بنجاح!', 'success')
        return redirect(url_for('vehicles.vehicle_safety_checks', id=id))
    
    return render_template(
        'vehicles/safety_check_create.html',
        vehicle=vehicle,
        supervisors=supervisors,
        check_types=SAFETY_CHECK_TYPE_CHOICES,
        check_statuses=SAFETY_CHECK_STATUS_CHOICES
    )

@vehicles_bp.route('/safety-check/<int:id>/edit', methods=['GET', 'POST'])
@login_required
def edit_safety_check(id):
    """تعديل سجل فحص سلامة"""
    safety_check = VehicleSafetyCheck.query.get_or_404(id)
    vehicle = Vehicle.query.get_or_404(safety_check.vehicle_id)
    
    # الحصول على قائمة السائقين والمشرفين
    supervisors = Employee.query.filter(Employee.job_title.contains('مشرف')).all()
    
    if request.method == 'POST':
        safety_check.check_date = datetime.strptime(request.form.get('check_date'), '%Y-%m-%d').date()
        safety_check.check_type = request.form.get('check_type')
        
        # معلومات السائق
        driver_id = request.form.get('driver_id')
        safety_check.driver_name = request.form.get('driver_name')
        
        # تحويل قيمة فارغة إلى None
        if not driver_id or driver_id == '':
            safety_check.driver_id = None
        else:
            safety_check.driver_id = driver_id
            driver = Employee.query.get(driver_id)
            if driver:
                safety_check.driver_name = driver.name
        
        # معلومات المشرف
        supervisor_id = request.form.get('supervisor_id')
        safety_check.supervisor_name = request.form.get('supervisor_name')
        
        # تحويل قيمة فارغة إلى None
        if not supervisor_id or supervisor_id == '':
            safety_check.supervisor_id = None
        else:
            safety_check.supervisor_id = supervisor_id
            supervisor = Employee.query.get(supervisor_id)
            if supervisor:
                safety_check.supervisor_name = supervisor.name
        
        safety_check.status = request.form.get('status')
        safety_check.check_form_link = request.form.get('check_form_link')
        safety_check.issues_found = bool(request.form.get('issues_found'))
        safety_check.issues_description = request.form.get('issues_description')
        safety_check.actions_taken = request.form.get('actions_taken')
        safety_check.notes = request.form.get('notes')
        safety_check.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        # تسجيل الإجراء
        log_audit('update', 'vehicle_safety_check', safety_check.id, f'تم تعديل سجل فحص سلامة للسيارة: {vehicle.plate_number}')
        
        flash('تم تعديل سجل فحص السلامة بنجاح!', 'success')
        return redirect(url_for('vehicles.vehicle_safety_checks', id=vehicle.id))
    
    return render_template(
        'vehicles/safety_check_edit.html',
        safety_check=safety_check,
        vehicle=vehicle,
        supervisors=supervisors,
        check_types=SAFETY_CHECK_TYPE_CHOICES,
        check_statuses=SAFETY_CHECK_STATUS_CHOICES
    )

@vehicles_bp.route('/safety-check/<int:id>/confirm-delete')
@login_required
def confirm_delete_safety_check(id):
    """عرض صفحة تأكيد حذف سجل فحص سلامة"""
    safety_check = VehicleSafetyCheck.query.get_or_404(id)
    vehicle = Vehicle.query.get_or_404(safety_check.vehicle_id)
    
    # تنسيق التاريخ
    safety_check.formatted_check_date = format_date_arabic(safety_check.check_date)
    
    return render_template(
        'vehicles/confirm_delete_safety_check.html',
        check=safety_check,
        vehicle=vehicle
    )

@vehicles_bp.route('/safety-check/<int:id>/delete', methods=['POST'])
@login_required
def delete_safety_check(id):
    """حذف سجل فحص سلامة"""
    safety_check = VehicleSafetyCheck.query.get_or_404(id)
    vehicle_id = safety_check.vehicle_id
    vehicle = Vehicle.query.get_or_404(vehicle_id)
    
    # تسجيل الإجراء قبل الحذف
    log_audit('delete', 'vehicle_safety_check', id, f'تم حذف سجل فحص سلامة للسيارة: {vehicle.plate_number}')
    
    db.session.delete(safety_check)
    db.session.commit()
    
    flash('تم حذف سجل فحص السلامة بنجاح!', 'success')
    return redirect(url_for('vehicles.vehicle_safety_checks', id=vehicle_id))

# إنشاء تقرير Excel شامل للسيارة
@vehicles_bp.route('/vehicle-report/<int:id>')
@login_required
def generate_vehicle_report(id):
    """إنشاء تقرير شامل للسيارة بصيغة Excel"""
    from flask import send_file, flash, redirect, url_for, make_response
    import io
    
    try:
        # الحصول على بيانات المركبة
        vehicle = Vehicle.query.get_or_404(id)
        
        # الحصول على بيانات الإيجار النشط
        rental = VehicleRental.query.filter_by(vehicle_id=id, is_active=True).first()
        
        # الحصول على سجلات الورشة
        workshop_records = VehicleWorkshop.query.filter_by(vehicle_id=id).order_by(
            VehicleWorkshop.entry_date.desc()
        ).all()
        
        # الحصول على سجلات التسليم/الاستلام
        handovers = VehicleHandover.query.filter_by(vehicle_id=id).order_by(
            VehicleHandover.handover_date.desc()
        ).all()
        
        # الحصول على سجلات الفحص
        inspections = VehiclePeriodicInspection.query.filter_by(vehicle_id=id).order_by(
            VehiclePeriodicInspection.inspection_date.desc()
        ).all()
        
        # هذا الموديل قد لا يكون موجودًا، لذلك سنتجاهله الآن
        documents = None
        
        # إنشاء التقرير الشامل
        excel_bytes = generate_complete_vehicle_excel_report(
            vehicle, 
            rental=rental, 
            workshop_records=workshop_records,
            documents=documents,
            handovers=handovers,
            inspections=inspections
        )
        
        # إرسال الملف للمستخدم
        buffer = io.BytesIO(excel_bytes)
        buffer.seek(0)  # إعادة تعيين موضع القراءة إلى بداية البيانات
        response = make_response(send_file(
            buffer,
            download_name=f'تقرير_شامل_{vehicle.plate_number}.xlsx',
            mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            as_attachment=True
        ))
        
        # تسجيل الإجراء
        log_audit('generate_report', 'vehicle', id, f'تم إنشاء تقرير شامل للسيارة (Excel): {vehicle.plate_number}')
        
        return response
        
    except Exception as e:
        flash(f'حدث خطأ أثناء إنشاء تقرير Excel: {str(e)}', 'danger')
        return redirect(url_for('vehicles.view', id=id))

@vehicles_bp.route('/update-drivers', methods=['POST'])
@login_required
def update_drivers():
    """تحديث جميع أسماء السائقين من سجلات التسليم"""
    try:
        updated_count = update_all_vehicle_drivers()
        flash(f'تم تحديث أسماء السائقين لـ {updated_count} سيارة بنجاح!', 'success')
    except Exception as e:
        flash(f'حدث خطأ أثناء التحديث: {str(e)}', 'danger')
    
    return redirect(url_for('vehicles.detailed'))

@vehicles_bp.route('/<int:vehicle_id>/current_employee')
@login_required
def get_current_employee(vehicle_id):
    """الحصول على معرف الموظف الحالي للسيارة"""
    try:
        employee_id = get_vehicle_current_employee_id(vehicle_id)
        return jsonify({
            'employee_id': employee_id
        })
    except Exception as e:
        return jsonify({
            'employee_id': None,
            'error': str(e)
        }), 500

